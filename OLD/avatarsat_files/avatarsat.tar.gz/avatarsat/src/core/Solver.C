/****************************************************************************************[Solver.C]
MiniSat -- Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#include "Solver.h"
#include "Sort.h"
#include <cmath>
#include <string>
#include <float.h>


//=================================================================================================
// Constructor/Destructor:


Solver::Solver() :

    // Parameters: (formerly in 'SearchParams')
    var_decay(1 / 0.95)
  , clause_decay(1 / 0.999)
  , random_var_freq(0.02)
  , restart_first(100)
  , restart_inc(1.5)
  , learntsize_factor((double)1/(double)3)
  , learntsize_inc(1.1)

    // More parameters:
    //
  , expensive_ccmin  (true)
  , polarity_mode    (polarity_false)
  , verbosity        (0)


    // Statistics: (formerly in 'SolverStats')
    //
  , starts(0), decisions(0)
  , rnd_decisions(0)
  , propagations(0)
  , conflicts(0)
  , clauses_literals(0)
  , learnts_literals(0)
  , max_literals(0)
  , tot_literals(0)
  , ok               (true)
  , cla_inc          (1)
  , var_inc          (1)
  , qhead            (0)
  , simpDB_assigns   (-1)
  , simpDB_props     (0)
  , order_heap       (VarOrderLt(activity))
  , random_seed      (91648253)
  , progress_estimate(0)
  , remove_satisfied (true)
  , firstiteration(1)
  , previous_learntclauses(0)
  , clauseDiffLimit(0.8)
  , model_filename("")
  , range_filename("")
  , pre_model_filename("")
  , pre_range_filename("")

{}


Solver::~Solver()
{
    for (int i = 0; i < learnts.size(); i++) free(learnts[i]);
    for (int i = 0; i < clauses.size(); i++) free(clauses[i]);
}


//=================================================================================================
// Minor methods:


// Creates a new SAT variable in the solver. If 'decision_var' is cleared, variable will not be
// used as a decision variable (NOTE! This has effects on the meaning of a SATISFIABLE result).
//
Var Solver::newVar(bool sign, bool dvar)
{
    int v = nVars();
    watches   .push();          // (list for positive literal)
    watches   .push();          // (list for negative literal)
    reason    .push(NULL);
    assigns   .push(toInt(l_Undef));
    level     .push(-1);
    activity  .push(0);
    seen      .push(0);

    polarity    .push((char)sign);
    decision_var.push((char)dvar);

    insertVarOrder(v);
    return v;
}


bool Solver::addClause(vec<Lit>& ps)
{
    assert(decisionLevel() == 0);

    if (!ok)
        return false;
    else{
        // Check if clause is satisfied and remove false/duplicate literals:
        sort(ps);
        Lit p; int i, j;
        for (i = j = 0, p = lit_Undef; i < ps.size(); i++)
            if (value(ps[i]) == l_True || ps[i] == ~p)
                return true;
            else if (value(ps[i]) != l_False && ps[i] != p)
                ps[j++] = p = ps[i];
        ps.shrink(i - j);
    }

    if (ps.size() == 0)
        return ok = false;
    else if (ps.size() == 1){
        assert(value(ps[0]) == l_Undef);
        uncheckedEnqueue(ps[0]);
        return ok = (propagate() == NULL);
    }else{
        Clause* c = Clause_new(ps, false);
        clauses.push(c);
        attachClause(*c);
    }

    return true;
}


void Solver::attachClause(Clause& c) {
    assert(c.size() > 1);
    watches[toInt(~c[0])].push(&c);
    watches[toInt(~c[1])].push(&c);
    if (c.learnt()) learnts_literals += c.size();
    else            clauses_literals += c.size(); }


void Solver::detachClause(Clause& c) {
    assert(c.size() > 1);
    assert(find(watches[toInt(~c[0])], &c));
    assert(find(watches[toInt(~c[1])], &c));
    remove(watches[toInt(~c[0])], &c);
    remove(watches[toInt(~c[1])], &c);
    if (c.learnt()) learnts_literals -= c.size();
    else            clauses_literals -= c.size(); }


void Solver::removeClause(Clause& c) {
    detachClause(c);
    free(&c); }


bool Solver::satisfied(const Clause& c) const {
    for (int i = 0; i < c.size(); i++)
        if (value(c[i]) == l_True)
            return true;
    return false; }


// Revert to the state at given level (keeping all assignment at 'level' but not beyond).
//
void Solver::cancelUntil(int level) {
    if (decisionLevel() > level){
        for (int c = trail.size()-1; c >= trail_lim[level]; c--){
            Var     x  = var(trail[c]);
            assigns[x] = toInt(l_Undef);
            insertVarOrder(x); }
        qhead = trail_lim[level];
        trail.shrink(trail.size() - trail_lim[level]);
        trail_lim.shrink(trail_lim.size() - level);
    } }


//=================================================================================================
// Major methods:


Lit Solver::pickBranchLit(int polarity_mode, double random_var_freq)
{
    Var next = var_Undef;

    // Random decision:
    if (drand(random_seed) < random_var_freq && !order_heap.empty()){
        next = order_heap[irand(random_seed,order_heap.size())];
        if (toLbool(assigns[next]) == l_Undef && decision_var[next])
            rnd_decisions++; }

    // Activity based decision:
    while (next == var_Undef || toLbool(assigns[next]) != l_Undef || !decision_var[next])
        if (order_heap.empty()){
            next = var_Undef;
            break;
        }else
            next = order_heap.removeMin();

    bool sign = false;
    switch (polarity_mode){
    case polarity_true:  sign = false; break;
    case polarity_false: sign = true;  break;
    case polarity_user:  sign = polarity[next]; break;
    case polarity_rnd:   sign = irand(random_seed, 2); break;
    default: assert(false); }

    return next == var_Undef ? lit_Undef : Lit(next, sign);
}


/*_________________________________________________________________________________________________
|
|  analyze : (confl : Clause*) (out_learnt : vec<Lit>&) (out_btlevel : int&)  ->  [void]
|  
|  Description:
|    Analyze conflict and produce a reason clause.
|  
|    Pre-conditions:
|      * 'out_learnt' is assumed to be cleared.
|      * Current decision level must be greater than root level.
|  
|    Post-conditions:
|      * 'out_learnt[0]' is the asserting literal at level 'out_btlevel'.
|  
|  Effect:
|    Will undo part of the trail, upto but not beyond the assumption of the current decision level.
|________________________________________________________________________________________________@*/
void Solver::analyze(Clause* confl, vec<Lit>& out_learnt, int& out_btlevel)
{
    int pathC = 0;
    Lit p     = lit_Undef;

    // Generate conflict clause:
    //
    out_learnt.push();      // (leave room for the asserting literal)
    int index   = trail.size() - 1;
    out_btlevel = 0;

    do{
        assert(confl != NULL);          // (otherwise should be UIP)
        Clause& c = *confl;

        if (c.learnt())
            claBumpActivity(c);

        for (int j = (p == lit_Undef) ? 0 : 1; j < c.size(); j++){
            Lit q = c[j];

            if (!seen[var(q)] && level[var(q)] > 0){
                varBumpActivity(var(q));
                seen[var(q)] = 1;
                if (level[var(q)] >= decisionLevel())
                    pathC++;
                else{
                    out_learnt.push(q);
                    if (level[var(q)] > out_btlevel)
                        out_btlevel = level[var(q)];
                }
            }
        }

        // Select next clause to look at:
        while (!seen[var(trail[index--])]);
        p     = trail[index+1];
        confl = reason[var(p)];
        seen[var(p)] = 0;
        pathC--;

    }while (pathC > 0);
    out_learnt[0] = ~p;

    // Simplify conflict clause:
    //
    int i, j;
    if (expensive_ccmin){
        uint32_t abstract_level = 0;
        for (i = 1; i < out_learnt.size(); i++)
            abstract_level |= abstractLevel(var(out_learnt[i])); // (maintain an abstraction of levels involved in conflict)

        out_learnt.copyTo(analyze_toclear);
        for (i = j = 1; i < out_learnt.size(); i++)
            if (reason[var(out_learnt[i])] == NULL || !litRedundant(out_learnt[i], abstract_level))
                out_learnt[j++] = out_learnt[i];
    }else{
        out_learnt.copyTo(analyze_toclear);
        for (i = j = 1; i < out_learnt.size(); i++){
            Clause& c = *reason[var(out_learnt[i])];
            for (int k = 1; k < c.size(); k++)
                if (!seen[var(c[k])] && level[var(c[k])] > 0){
                    out_learnt[j++] = out_learnt[i];
                    break; }
        }
    }
    max_literals += out_learnt.size();
    out_learnt.shrink(i - j);
    tot_literals += out_learnt.size();

    // Find correct backtrack level:
    //
    if (out_learnt.size() == 1)
        out_btlevel = 0;
    else{
        int max_i = 1;
        for (int i = 2; i < out_learnt.size(); i++)
            if (level[var(out_learnt[i])] > level[var(out_learnt[max_i])])
                max_i = i;
        Lit p             = out_learnt[max_i];
        out_learnt[max_i] = out_learnt[1];
        out_learnt[1]     = p;
        out_btlevel       = level[var(p)];
    }


    for (int j = 0; j < analyze_toclear.size(); j++) seen[var(analyze_toclear[j])] = 0;    // ('seen[]' is now cleared)
}


// Check if 'p' can be removed. 'abstract_levels' is used to abort early if the algorithm is
// visiting literals at levels that cannot be removed later.
bool Solver::litRedundant(Lit p, uint32_t abstract_levels)
{
    analyze_stack.clear(); analyze_stack.push(p);
    int top = analyze_toclear.size();
    while (analyze_stack.size() > 0){
        assert(reason[var(analyze_stack.last())] != NULL);
        Clause& c = *reason[var(analyze_stack.last())]; analyze_stack.pop();

        for (int i = 1; i < c.size(); i++){
            Lit p  = c[i];
            if (!seen[var(p)] && level[var(p)] > 0){
                if (reason[var(p)] != NULL && (abstractLevel(var(p)) & abstract_levels) != 0){
                    seen[var(p)] = 1;
                    analyze_stack.push(p);
                    analyze_toclear.push(p);
                }else{
                    for (int j = top; j < analyze_toclear.size(); j++)
                        seen[var(analyze_toclear[j])] = 0;
                    analyze_toclear.shrink(analyze_toclear.size() - top);
                    return false;
                }
            }
        }
    }

    return true;
}


/*_________________________________________________________________________________________________
|
|  analyzeFinal : (p : Lit)  ->  [void]
|  
|  Description:
|    Specialized analysis procedure to express the final conflict in terms of assumptions.
|    Calculates the (possibly empty) set of assumptions that led to the assignment of 'p', and
|    stores the result in 'out_conflict'.
|________________________________________________________________________________________________@*/
void Solver::analyzeFinal(Lit p, vec<Lit>& out_conflict)
{
    out_conflict.clear();
    out_conflict.push(p);

    if (decisionLevel() == 0)
        return;

    seen[var(p)] = 1;

    for (int i = trail.size()-1; i >= trail_lim[0]; i--){
        Var x = var(trail[i]);
        if (seen[x]){
            if (reason[x] == NULL){
                assert(level[x] > 0);
                out_conflict.push(~trail[i]);
            }else{
                Clause& c = *reason[x];
                for (int j = 1; j < c.size(); j++)
                    if (level[var(c[j])] > 0)
                        seen[var(c[j])] = 1;
            }
            seen[x] = 0;
        }
    }

    seen[var(p)] = 0;
}


void Solver::uncheckedEnqueue(Lit p, Clause* from)
{
    assert(value(p) == l_Undef);
    assigns [var(p)] = toInt(lbool(!sign(p)));  // <<== abstract but not uttermost effecient
    level   [var(p)] = decisionLevel();
    reason  [var(p)] = from;
    trail.push(p);
}


/*_________________________________________________________________________________________________
|
|  propagate : [void]  ->  [Clause*]
|  
|  Description:
|    Propagates all enqueued facts. If a conflict arises, the conflicting clause is returned,
|    otherwise NULL.
|  
|    Post-conditions:
|      * the propagation queue is empty, even if there was a conflict.
|________________________________________________________________________________________________@*/
Clause* Solver::propagate()
{
    Clause* confl     = NULL;
    int     num_props = 0;

    while (qhead < trail.size()){
        Lit            p   = trail[qhead++];     // 'p' is enqueued fact to propagate.
        vec<Clause*>&  ws  = watches[toInt(p)];
        Clause         **i, **j, **end;
        num_props++;

        for (i = j = (Clause**)ws, end = i + ws.size();  i != end;){
            Clause& c = **i++;

            // Make sure the false literal is data[1]:
            Lit false_lit = ~p;
            if (c[0] == false_lit)
                c[0] = c[1], c[1] = false_lit;

            assert(c[1] == false_lit);

            // If 0th watch is true, then clause is already satisfied.
            Lit first = c[0];
            if (value(first) == l_True){
                *j++ = &c;
            }else{
                // Look for new watch:
                for (int k = 2; k < c.size(); k++)
                    if (value(c[k]) != l_False){
                        c[1] = c[k]; c[k] = false_lit;
                        watches[toInt(~c[1])].push(&c);
                        goto FoundWatch; }

                // Did not find watch -- clause is unit under assignment:
                *j++ = &c;
                if (value(first) == l_False){
                    confl = &c;
                    qhead = trail.size();
                    // Copy the remaining watches:
                    while (i < end)
                        *j++ = *i++;
                }else
                    uncheckedEnqueue(first, &c);
            }
        FoundWatch:;
        }
        ws.shrink(i - j);
    }
    propagations += num_props;
    simpDB_props -= num_props;

    return confl;
}

/*_________________________________________________________________________________________________
|
|  reduceDB : ()  ->  [void]
|  
|  Description:
|    Remove half of the learnt clauses, minus the clauses locked by the current assignment. Locked
|    clauses are clauses that are reason to some assignment. Binary clauses are never removed.
|________________________________________________________________________________________________@*/
struct reduceDB_lt { bool operator () (Clause* x, Clause* y) { return x->size() > 2 && (y->size() == 2 || x->activity() < y->activity()); } };
void Solver::reduceDB()
{
    int     i, j;
    double  extra_lim = cla_inc / learnts.size();    // Remove any clause below this activity

    sort(learnts, reduceDB_lt());
    for (i = j = 0; i < learnts.size() / 2; i++){
        if (learnts[i]->size() > 2 && !locked(*learnts[i]))
            removeClause(*learnts[i]);
        else
            learnts[j++] = learnts[i];
    }
    for (; i < learnts.size(); i++){
        if (learnts[i]->size() > 2 && !locked(*learnts[i]) && learnts[i]->activity() < extra_lim)
            removeClause(*learnts[i]);
        else
            learnts[j++] = learnts[i];
    }
    learnts.shrink(i - j);
}


void Solver::removeSatisfied(vec<Clause*>& cs)
{
    int i,j;
    for (i = j = 0; i < cs.size(); i++){
        if (satisfied(*cs[i]))
            removeClause(*cs[i]);
        else
            cs[j++] = cs[i];
    }
    cs.shrink(i - j);
}


/*_________________________________________________________________________________________________
|
|  simplify : [void]  ->  [bool]
|  
|  Description:
|    Simplify the clause database according to the current top-level assigment. Currently, the only
|    thing done here is the removal of satisfied clauses, but more things can be put here.
|________________________________________________________________________________________________@*/
bool Solver::simplify()
{
    assert(decisionLevel() == 0);

    if (!ok || propagate() != NULL)
        return ok = false;

    if (nAssigns() == simpDB_assigns || (simpDB_props > 0))
        return true;

    // Remove satisfied clauses:
    removeSatisfied(learnts);
    if (remove_satisfied)        // Can be turned off.
        removeSatisfied(clauses);

    // Remove fixed variables from the variable heap:
    order_heap.filter(VarFilter(*this));

    simpDB_assigns = nAssigns();
    simpDB_props   = clauses_literals + learnts_literals;   // (shouldn't depend on stats really, but it will do for now)

    return true;
}


/*_________________________________________________________________________________________________
|
|  search : (nof_conflicts : int) (nof_learnts : int) (params : const SearchParams&)  ->  [lbool]
|  
|  Description:
|    Search for a model the specified number of conflicts, keeping the number of learnt clauses
|    below the provided limit. NOTE! Use negative value for 'nof_conflicts' or 'nof_learnts' to
|    indicate infinity.
|  
|  Output:
|    'l_True' if a partial assigment that is consistent with respect to the clauseset is found. If
|    all variables are decision variables, this means that the clause set is satisfiable. 'l_False'
|    if the clause set is unsatisfiable. 'l_Undef' if the bound on number of conflicts is reached.
|________________________________________________________________________________________________@*/
lbool Solver::search(int nof_conflicts, int nof_learnts)
{
    assert(ok);
    int         backtrack_level;
    int         conflictC = 0;
    vec<Lit>    learnt_clause;

    starts++;

    bool first = true;

    for (;;){
        Clause* confl = propagate();
        if (confl != NULL){
            // CONFLICT
            conflicts++; conflictC++;
            if (decisionLevel() == 0) return l_False;

            first = false;

            learnt_clause.clear();
            analyze(confl, learnt_clause, backtrack_level);
            cancelUntil(backtrack_level);
            assert(value(learnt_clause[0]) == l_Undef);

            if (learnt_clause.size() == 1){
                uncheckedEnqueue(learnt_clause[0]);
            }else{
                Clause* c = Clause_new(learnt_clause, true);
                learnts.push(c);
                attachClause(*c);
                claBumpActivity(*c);
                uncheckedEnqueue(learnt_clause[0], c);
            }

            varDecayActivity();
            claDecayActivity();

        }else{
            // NO CONFLICT

            if (nof_conflicts >= 0 && conflictC >= nof_conflicts){
                // Reached bound on number of conflicts:
                progress_estimate = progressEstimate();
                cancelUntil(0);
                return l_Undef; }

            // Simplify the set of problem clauses:
            if (decisionLevel() == 0 && !simplify())
                return l_False;

            if (nof_learnts >= 0 && learnts.size()-nAssigns() >= nof_learnts)
                // Reduce the set of learnt clauses:
                reduceDB();

            Lit next = lit_Undef;
            while (decisionLevel() < assumptions.size()){
                // Perform user provided assumption:
                Lit p = assumptions[decisionLevel()];
                if (value(p) == l_True){
                    // Dummy decision level:
                    newDecisionLevel();
                }else if (value(p) == l_False){
                    analyzeFinal(~p, conflict);
                    return l_False;
                }else{
                    next = p;
                    break;
                }
            }

            if (next == lit_Undef){
                // New variable decision:
                decisions++;
                next = pickBranchLit(polarity_mode, random_var_freq);

                if (next == lit_Undef)
                    // Model found:
                    return l_True;
            }

            // Increase decision level and enqueue 'next'
            assert(value(next) == l_Undef);
            newDecisionLevel();
            uncheckedEnqueue(next);
        }
    }
}


double Solver::progressEstimate() const
{
    double  progress = 0;
    double  F = 1.0 / nVars();

    for (int i = 0; i <= decisionLevel(); i++){
        int beg = i == 0 ? 0 : trail_lim[i - 1];
        int end = i == decisionLevel() ? trail.size() : trail_lim[i];
        progress += pow(F, i) * (end - beg);
    }

    return progress / nVars();
}



int Solver::logn(int val) {
  
  if(val<=0) return 0;

  return (int)(log(val)/log(1.05));

}



struct svm_node* Solver::FeatureGenerator(struct range *featurerange) {  
  struct svm_node *x;
  int varnumber;
  int numvars=nVars();
  int numclauses=nClauses()+nLearnts();
  int wsum[numvars],totallits[numvars],wnegsum[numvars],wpossum[numvars],neglits[numvars],poslits[numvars];
  int clausenum=numclauses;
  int maxclen=0,minclen=100000000;
  int totclen=0;
  int binaries=0,ternaries=0,quadraries=0; 
  int maxtotallits=0,maxindextotallits=-1,maxposlits=0,maxindexposlits=-1,maxneglits=0,maxindexneglits=-1;
  int negclausesum=0,posclausesum=0;
  int pos=0,neg=0,total=0;
  int mintotallits=1000000,minposlits=1000000,minneglits=10000000;
  int maxratioclauses=0,minratioclauses=100000,totratioclauses=0;

  x=(struct svm_node *)malloc(NFEATURES*sizeof(struct svm_node));

  

  for(int i=0;i<numvars;i++){
    wsum[i]=0;
    totallits[i]=0;
    wnegsum[i]=0;
    wpossum[i]=0;
    neglits[i]=1;
    poslits[i]=1;
  }

  for (int i = 0; i < clauses.size(); i++){
    Clause& c = *clauses[i]; 
    int clen=0;
    int pospresent=0,negpresent=0;
    int cneglits=1, cposlits=1;
     for (int j = 0; j < c.size(); j++){
       int varname=var(c[j])+1;
       if(sign(c[j])){
	 cneglits++;
	 neg++;
	 negpresent=1;
	 varnumber=-varname;
       }
       else{
	 cposlits++;
	 pos++;
	 pospresent=1;
	 varnumber=varname;
       }
       total++;
       wsum[varname-1]+=clausenum;
       clen++;
       totallits[varname-1]++;
       if(totallits[varname-1]>maxtotallits){
	 maxtotallits=totallits[varname-1];
	 maxindextotallits=varname-1;
       }
       if(totallits[varname-1]<mintotallits) mintotallits=totallits[varname-1];
	 

       if(varnumber<0){
	 wnegsum[varname-1]+=clausenum;
	 neglits[varname-1]++;
	 if(neglits[varname-1]>maxneglits){
	   maxneglits=neglits[varname-1];
	   maxindexneglits=varname-1;
	 }
	 if(neglits[varname-1]<minneglits) minneglits=neglits[varname-1];
       }else{
	 wpossum[varname-1]+=clausenum;
	 poslits[varname-1]++;
	 if(poslits[varname-1]>maxposlits){
	   maxposlits=poslits[varname-1];
	   maxindexposlits=varname-1;
	 }
	  if(poslits[varname-1]<minposlits) minposlits=poslits[varname-1];
       }
       
       
       
     }

     if( (cposlits*100/cneglits) > maxratioclauses) maxratioclauses=(int) (cposlits*100/cneglits);
     
     if( (cposlits*100/cneglits) < minratioclauses) minratioclauses=(int) (cposlits*100/cneglits);

     totratioclauses+= (int) (cposlits*100/cneglits);

     if(pospresent==0) negclausesum+=clausenum;
     if(negpresent==0) posclausesum+=clausenum;
     
     clausenum--;

     if(clen>maxclen) maxclen=clen;
     if(clen<minclen) minclen=clen;
     totclen+=clen;

     if(clen==2) binaries++;
     if(clen==3) ternaries++;
     if(clen==4) quadraries++;
  }

  //Learnts Clauses
 for (int i = 0; i < learnts.size(); i++){
    Clause& c = *learnts[i]; 
    int clen=0;
    int pospresent=0,negpresent=0;
    int cneglits=1, cposlits=1;
     for (int j = 0; j < c.size(); j++){
       int varname=var(c[j])+1;
       if(sign(c[j])){
	 cneglits++;
	 neg++;
	 negpresent=1;
	 varnumber=-varname;
       }
       else{
	 cposlits++;
	 pos++;
	 pospresent=1;
	 varnumber=varname;
       }
       total++;
       wsum[varname-1]+=clausenum;
       clen++;
       totallits[varname-1]++;
       if(totallits[varname-1]>maxtotallits){
	 maxtotallits=totallits[varname-1];
	 maxindextotallits=varname-1;
       }
       if(totallits[varname-1]<mintotallits) mintotallits=totallits[varname-1];
	 

       if(varnumber<0){
	 wnegsum[varname-1]+=clausenum;
	 neglits[varname-1]++;
	 if(neglits[varname-1]>maxneglits){
	   maxneglits=neglits[varname-1];
	   maxindexneglits=varname-1;
	 }
	 if(neglits[varname-1]<minneglits) minneglits=neglits[varname-1];
       }else{
	 wpossum[varname-1]+=clausenum;
	 poslits[varname-1]++;
	 if(poslits[varname-1]>maxposlits){
	   maxposlits=poslits[varname-1];
	   maxindexposlits=varname-1;
	 }
	  if(poslits[varname-1]<minposlits) minposlits=poslits[varname-1];
       }
       
       
       
     }

     if((cposlits*100/cneglits) > maxratioclauses) 
       maxratioclauses=(int) (cposlits*100/cneglits);
     
     if((cposlits*100/cneglits) < minratioclauses) 
       minratioclauses=(int) (cposlits*100/cneglits);

     totratioclauses+= (int) (cposlits*100/cneglits);

     if(pospresent==0) negclausesum+=clausenum;
     if(negpresent==0) posclausesum+=clausenum;
     
     clausenum--;

     if(clen>maxclen) maxclen=clen;
     if(clen<minclen) minclen=clen;
     totclen+=clen;

     if(clen==2) binaries++;
     if(clen==3) ternaries++;
     if(clen==4) quadraries++;



  }


  int totratio=0,maxratio=0,minratio=100000;

  for(int i=0;i<numvars;i++){
    int ratio = (int)poslits[i]*100/neglits[i];
    totratio+= ratio;
    if(ratio>maxratio) maxratio=ratio;
    if(ratio<minratio) minratio=ratio;
  }


  int idx=0; 
 


  // number of variables
  if(featurerange->maxvalue[0]!=DBL_MIN){
    x[idx].index = 1;
    x[idx].value = logn(numvars);
    idx++;
  }
  
  // number of clauses
  if(featurerange->maxvalue[1]!=DBL_MIN){
    x[idx].index = 2;
    x[idx].value =  logn(numclauses);
    idx++;
  }

  // positive occurences
  if(featurerange->maxvalue[2]!=DBL_MIN){
    x[idx].index = 3;
    x[idx].value =  logn(pos);
    idx++;
  }

  // negative occurences
  if(featurerange->maxvalue[3]!=DBL_MIN){
    x[idx].index = 4;
    x[idx].value =  logn(neg);
    idx++;
  }

  // high number of total occurences
  if(featurerange->maxvalue[4]!=DBL_MIN){
    x[idx].index = 5;
    x[idx].value =  logn(maxtotallits);
    idx++;
  }

  // low number of total occurences
  if(featurerange->maxvalue[5]!=DBL_MIN){
    x[idx].index = 6;
    x[idx].value =  logn(mintotallits);
    idx++;
  }

  // high number of pos occurences
  if(featurerange->maxvalue[6]!=DBL_MIN){
    x[idx].index = 7;
    x[idx].value =  logn(maxposlits);
    idx++;
  }

  // low number of pos occurences
  if(featurerange->maxvalue[7]!=DBL_MIN){
    x[idx].index = 8;
    x[idx].value =  logn(minposlits);
    idx++;
  }

  // high number of neg occurences
  if(featurerange->maxvalue[8]!=DBL_MIN){
    x[idx].index = 9;
    x[idx].value =  logn(maxneglits);
    idx++;
  }

  // low number of neg occurences
  if(featurerange->maxvalue[9]!=DBL_MIN){
    x[idx].index = 10;
    x[idx].value =  logn(minneglits);
    idx++;
  }

  // longest clause length
  if(featurerange->maxvalue[10]!=DBL_MIN){
    x[idx].index = 11;
    x[idx].value =  logn(maxclen);
    idx++;
  }
  
  // shortest clause length
  if(featurerange->maxvalue[11]!=DBL_MIN){
    x[idx].index = 12;
    x[idx].value =  logn(minclen);
    idx++;
  }

  int ClauseVarRatio = (int)numclauses*10/numvars;
  
  // average clause length
  if(featurerange->maxvalue[12]!=DBL_MIN){
    x[idx].index = 13;
    x[idx].value =  logn((int)totclen/numclauses);
    idx++;
  }
  
  // num binary clauses
  if(featurerange->maxvalue[13]!=DBL_MIN){
    x[idx].index = 14;
    x[idx].value =  logn(binaries);
    idx++;
  }

  // num ternary clauses
  if(featurerange->maxvalue[14]!=DBL_MIN){
    x[idx].index = 15;
    x[idx].value =  logn(ternaries);
    idx++;
  }

  // num quadrary clauses
  if(featurerange->maxvalue[15]!=DBL_MIN){
    x[idx].index = 16;
    x[idx].value =  logn(quadraries);
    idx++;
  }

  // clause/var ratio
  if(featurerange->maxvalue[16]!=DBL_MIN){
    x[idx].index = 17;
    x[idx].value =  ClauseVarRatio;
    idx++;
  }

  // clause/var ratio square
  if(featurerange->maxvalue[17]!=DBL_MIN){
    x[idx].index = 18;
    x[idx].value =  logn((int)ClauseVarRatio*ClauseVarRatio/10);
    idx++;
  }

  // clause/var ratio cube
  if(featurerange->maxvalue[18]!=DBL_MIN){
    x[idx].index = 19;
    x[idx].value =  logn((int)ClauseVarRatio*ClauseVarRatio*ClauseVarRatio/100);
    idx++;
  }

  int VarClauseRatio = (int)numvars*1000/numclauses;

  // var/clause ratio
  if(featurerange->maxvalue[19]!=DBL_MIN){
    x[idx].index = 20;
    x[idx].value =  VarClauseRatio;
    idx++;
  }

  // var/clause ratio square
  if(featurerange->maxvalue[20]!=DBL_MIN){
    x[idx].index = 21;
    x[idx].value =  logn((int)VarClauseRatio*VarClauseRatio/10);
    idx++;
  }
  
  // var/clause ratio cube
  if(featurerange->maxvalue[21]!=DBL_MIN){
    x[idx].index = 22;
    x[idx].value =  logn((int)VarClauseRatio*VarClauseRatio*VarClauseRatio/100);
    idx++;
  }

  int DifferenceRatio=abs(42-ClauseVarRatio);

  // difference ratio 4.2 - clause/var
  if(featurerange->maxvalue[22]!=DBL_MIN){
    x[idx].index = 23;
    x[idx].value =  DifferenceRatio;
    idx++;
  }

  // difference ratio square
  if(featurerange->maxvalue[23]!=DBL_MIN){
    x[idx].index = 24;
    x[idx].value =  logn((int)DifferenceRatio*DifferenceRatio/10);
    idx++;
  }

  // difference ratio cube
  if(featurerange->maxvalue[24]!=DBL_MIN){
    x[idx].index = 25;
    x[idx].value =  logn((int)DifferenceRatio*DifferenceRatio*DifferenceRatio/100);
    idx++;
  }

  // weighted occurence of highest literal
  if(featurerange->maxvalue[25]!=DBL_MIN){
    x[idx].index=26;
    x[idx].value =  logn(wsum[maxindextotallits]);
    idx++;
  }

  // weighted positive literals
  if(featurerange->maxvalue[26]!=DBL_MIN){
    x[idx].index=27;
    x[idx].value =  logn(wpossum[maxindexposlits]);
    idx++;
  }

  //weighted negative literals
  if(featurerange->maxvalue[27]!=DBL_MIN){
    x[idx].index=28;
    x[idx].value =  logn(wnegsum[maxindexneglits]);
    idx++;
  }

  // weighted positive clause literals
  if(featurerange->maxvalue[28]!=DBL_MIN){
    x[idx].index = 29;
    x[idx].value =  logn(posclausesum);
    idx++;
  }

  // weighted negative clause literals
  if(featurerange->maxvalue[29]!=DBL_MIN){
    x[idx].index = 30;
    x[idx].value =  logn(negclausesum);
    idx++;
  }

  // avg ratio of positive/negative lits per var
  if(featurerange->maxvalue[30]!=DBL_MIN){
    x[idx].index = 31;
    x[idx].value =  logn((int) totratio/numvars);
    idx++;
  }
  
  // max ratio of positive/negative lits per var
  if(featurerange->maxvalue[31]!=DBL_MIN){
    x[idx].index = 32;
    x[idx].value =  logn(maxratio);
    idx++;
  }

  // min ratio of positive/negative lits per var
  if(featurerange->maxvalue[32]!=DBL_MIN){
    x[idx].index = 33;
    x[idx].value =  logn(minratio);
    idx++;
  }

  // max ratio of positive/neg lits per clause
  if(featurerange->maxvalue[33]!=DBL_MIN){
    x[idx].index = 34;
    x[idx].value =  logn(maxratioclauses);
    idx++;
  }

  // min ratio of positive/neg lits per clause
  if(featurerange->maxvalue[34]!=DBL_MIN){
    x[idx].index = 35;
    x[idx].value =  logn(minratioclauses);
    idx++;
  }

  // avg ratio of positive/neg lits per clause
  if(featurerange->maxvalue[35]!=DBL_MIN){
    x[idx].index = 36;
    x[idx].value =  logn((int)totratioclauses/numclauses);
    idx++;
  }

  // Square of avg ratio of positive/neg lits per clause
  if(featurerange->maxvalue[36]!=DBL_MIN){
    x[idx].index = 37;
    x[idx].value =  logn((int)(totratioclauses/numclauses)*(totratioclauses/numclauses));
    idx++;
  }

  // Cube of avg ratio of positive/neg lits per clause
  if(featurerange->maxvalue[37]!=DBL_MIN){
    x[idx].index = 38;
    x[idx].value =  logn((int)(totratioclauses/numclauses)*
			 (totratioclauses/numclauses)*
			 (totratioclauses/numclauses));
    idx++;
  }

  // Square of weighted occurence of highest literal
  if(featurerange->maxvalue[38]!=DBL_MIN){
    x[idx].index=39;
    x[idx].value =  logn(wsum[maxindextotallits]*wsum[maxindextotallits]);
    idx++;
  }

  // Square of weighted positive literals
  if(featurerange->maxvalue[39]!=DBL_MIN){
    x[idx].index=40;
    x[idx].value =  logn(wpossum[maxindexposlits]*wpossum[maxindexposlits]);
    idx++;
  }

  //Square of weighted negative literals
  if(featurerange->maxvalue[40]!=DBL_MIN){
    x[idx].index=41;
    x[idx].value =  logn(wnegsum[maxindexneglits]*wnegsum[maxindexneglits]);
    idx++;
  }

  //Square of weighted positive clause literals
  if(featurerange->maxvalue[41]!=DBL_MIN){
    x[idx].index = 42;
    x[idx].value =  logn(posclausesum*posclausesum);
    idx++;
  }

  // Square of weighted negative clause literals
  if(featurerange->maxvalue[42]!=DBL_MIN){
    x[idx].index = 43;
    x[idx].value =  logn(negclausesum*negclausesum);
    idx++;
  }

  // Square of avg ratio of positive/negative lits per var
  if(featurerange->maxvalue[43]!=DBL_MIN){
    x[idx].index = 44;
    x[idx].value =  logn((int) (totratio/numvars)*(totratio/numvars));
    idx++;
  }
  
  //Square of max ratio of positive/negative lits per var
  if(featurerange->maxvalue[44]!=DBL_MIN){
    x[idx].index = 45;
    x[idx].value =  logn(maxratio*maxratio);
    idx++;
  }

  //Square of min ratio of positive/negative lits per var
  if(featurerange->maxvalue[45]!=DBL_MIN){
    x[idx].index = 46;
    x[idx].value =  logn(minratio*minratio);
    idx++;
  }

  //Square of max ratio of positive/neg lits per clause
  if(featurerange->maxvalue[46]!=DBL_MIN){
    x[idx].index = 47;
    x[idx].value =  logn(maxratioclauses*maxratioclauses);
    idx++;
  }

  //Square min ratio of positive/neg lits per clause
  if(featurerange->maxvalue[47]!=DBL_MIN){
    x[idx].index = 48;
    x[idx].value =  logn(minratioclauses*minratioclauses);
    idx++;
  }

  // Cube of weighted occurence of highest literal
  if(featurerange->maxvalue[48]!=DBL_MIN){
    x[idx].index = 49;
    x[idx].value = logn(wsum[maxindextotallits]*wsum[maxindextotallits]*wsum[maxindextotallits]);
    idx++;
  }
  

  // Cube of weighted positive literals
  if(featurerange->maxvalue[49]!=DBL_MIN){
    x[idx].index = 50;
    x[idx].value = logn(wpossum[maxindexposlits]*wpossum[maxindexposlits]*wpossum[maxindexposlits]);
    idx++;
  }
  

  //Cube of weighted negative literals
  if(featurerange->maxvalue[50]!=DBL_MIN){
    x[idx].index = 51;
    x[idx].value = logn(wnegsum[maxindexneglits]*wnegsum[maxindexneglits]*wnegsum[maxindexneglits]);
    idx++;
  }
  

  //Cube of weighted positive clause literals
  if(featurerange->maxvalue[51]!=DBL_MIN){
    x[idx].index = 52;
    x[idx].value = logn(posclausesum*posclausesum*posclausesum);
    idx++;
  }
  

  // Cube of weighted negative clause literals
  if(featurerange->maxvalue[52]!=DBL_MIN){
    x[idx].index = 53;
    x[idx].value = logn(negclausesum*negclausesum*negclausesum);
    idx++;
  }
  

  // Cube of avg ratio of positive/negative lits per var
  if(featurerange->maxvalue[53]!=DBL_MIN){
    x[idx].index = 54;
    x[idx].value = logn((int) (totratio/numvars)*(totratio/numvars)*(totratio/numvars));
    idx++;
  }
  
  
  //Cube of max ratio of positive/negative lits per var
  if(featurerange->maxvalue[54]!=DBL_MIN){
    x[idx].index = 55;
    x[idx].value = logn(maxratio*maxratio*maxratio);
    idx++;
  }
  

  //Cube of min ratio of positive/negative lits per var
  if(featurerange->maxvalue[55]!=DBL_MIN){
    x[idx].index = 56;
    x[idx].value = logn(minratio*minratio*minratio);
    idx++;
  }
  

  //Cube of max ratio of positive/neg lits per clause
  if(featurerange->maxvalue[56]!=DBL_MIN){
    x[idx].index = 57;
    x[idx].value = logn(maxratioclauses*maxratioclauses*maxratioclauses);
    idx++;
  }
  

  //Cube min ratio of positive/neg lits per clause
  if(featurerange->maxvalue[57]!=DBL_MIN){
    x[idx].index = 58;
    x[idx].value = logn(minratioclauses*minratioclauses*minratioclauses);
    idx++;
  }

  x[idx].index=-1;
  x[idx].value=0;

 
  int rangeidx=0;
  for(int i=0;i<idx;i++)
    {
      while(featurerange->maxvalue[rangeidx]==DBL_MIN)
	rangeidx++;      
      x[i].value=
	featurerange->lower+((x[i].value-featurerange->minvalue[rangeidx])*
			     (featurerange->upper - featurerange->lower)/(featurerange->maxvalue[rangeidx]-featurerange->minvalue[rangeidx]));
      rangeidx++;
    }     
  printf("\n");
  /*
    for(int i=0;i<idx;i++)
    {
    printf("%d:%lf ",x[i].index,x[i].value);
    }
    printf("\n");
  */
  return x;
} //end of FeatureGenerator

struct range * Solver::readrange(FILE *fp_restore){
  struct range *range;
  double lower,upper;
  int idx;
  double fmin, fmax;
		
  range=(struct range*)malloc(sizeof(struct range));

  if(fp_restore==NULL)
    {
      fprintf(stderr,"can't open file range\n");
      exit(1);
    }
  for(int i=0;i<NFEATURES-1;i++)
    range->maxvalue[i]=range->minvalue[i]=DBL_MIN;

  if (fgetc(fp_restore) == 'x') {
    fscanf(fp_restore, "%lf %lf\n", &lower, &upper);
    range->lower=lower;
    range->upper=upper;
  while(fscanf(fp_restore,"%d %lf %lf\n",&idx,&fmin,&fmax)==3)
      {
	range->maxvalue[idx-1]=fmax;
	range->minvalue[idx-1]=fmin;
      }
  }
  fclose(fp_restore);

  return range;
}


void debugRange(struct range *range1){

  printf("*********Debugging Range*********\n");
  printf("lower=%lf upper=%lf\n",range1->lower,range1->upper);
  for(int i=0;i<NFEATURES-1;i++){
    printf("feature_number=%d maxvalue=%lf minvalue=%lf\n",i,range1->maxvalue[i],range1->minvalue[i]);
  }


}




bool Solver::solve(const vec<Lit>& assumps)
{
  struct svm_model *svmmodel1,*svmmodel2;
  struct range *range1;

  struct svm_model *pre_svmmodel1,*pre_svmmodel2;
  struct range *pre_range1;

  double possibleDecays[]={0.50,0.75,0.85,0.91,0.93,0.95,0.97,0.99,0.999};
  double possibleRestarts[]={1,1.25,1.5};

  range_filename = "/usr/local/share/avatarsat/range-correction";
  pre_range_filename = "/usr/local/share/avatarsat/range-preprocessor";

  model_filename = (char*)malloc(sizeof("/usr/local/share/avatarsat/correction.model1")+sizeof("model2"));
  model_filename = strcpy(model_filename,"/usr/local/share/avatarsat/correction.model1");

  pre_model_filename = (char*)malloc(sizeof("/usr/local/share/avatarsat/preprocessor.model1")+sizeof("model2"));
  pre_model_filename = strcpy(pre_model_filename,"/usr/local/share/avatarsat/preprocessor.model1");


  
  // try to find correction model
  FILE *corr_fp_model = fopen(model_filename,"r");
  if (!corr_fp_model) {
    model_filename = (char*)malloc(sizeof("../models/correction.model1")+sizeof("model2"));
    model_filename = strcpy(model_filename,"../models/correction.model1");
  } else {
    fclose(corr_fp_model);
  }

  // try to find correction range
  FILE *fp_range = fopen(range_filename,"r");
  if (!fp_range) {
    fp_range = fopen("../models/range-correction", "r");
  }
  if (!fp_range) {
    printf("error: can't find course correction range file\n");
    exit(1);
  }

  // try to find preproccessor range
  FILE *pre_fp_range = fopen(pre_range_filename,"r");
  if (!pre_fp_range) {
    pre_fp_range = fopen("../models/range-correction", "r");
  }
  if (!pre_fp_range) {
    printf("error: can't find preprocessor range file\n");
    exit(1);
  }

  // try to find preproccessor model
  FILE *pre_fp_model = fopen(pre_model_filename,"r");
  if (!pre_fp_model) {
    pre_model_filename = (char*)malloc(sizeof("../models/preprocessor.model1")+sizeof("model2"));
    pre_model_filename = strcpy(pre_model_filename,"../models/preprocessor.model1");
  } else {
    fclose(pre_fp_model);
  }

  // load the course correction model
  svmmodel1=svm_load_model(model_filename);
  strcat(model_filename, "model2");
  svmmodel2=svm_load_model(model_filename);
  range1=readrange(fp_range);

  // load the preprocessor model
  pre_svmmodel1=svm_load_model(pre_model_filename);
  strcat(pre_model_filename, "model2");
  pre_svmmodel2=svm_load_model(pre_model_filename);
  pre_range1=readrange(pre_fp_range);

  // generate features
  struct svm_node *init_features;
  init_features=FeatureGenerator(pre_range1);
  int pre_predictedDecay=(int)svm_predict(pre_svmmodel1,init_features);
  int pre_predictedRestartInc=(int)svm_predict(pre_svmmodel2,init_features);

  float pre_newVarDecay=possibleDecays[pre_predictedDecay-1];
  float pre_newRestartInc=possibleRestarts[pre_predictedRestartInc-1];
  
  var_decay=(1/pre_newVarDecay);
  restart_inc=pre_newRestartInc;

  printf("|                                                                             |\n");
  printf("|  Preprocessor: setting var decay of %3.3lf and restart increment of %3.3lf    |\n", pre_newVarDecay, pre_newRestartInc);


  

  // miniSAT code
  model.clear();
  conflict.clear();
  
  if (!ok) return false;
  
  assumps.copyTo(assumptions);
  
  double  nof_conflicts = restart_first;
  double  nof_learnts   = nClauses() * learntsize_factor;
  lbool   status        = l_Undef;
  
  if (verbosity >= 1){
    reportf("=======================================[ Search Statistics ]========================================\n");
    reportf("| Conflicts |          ORIGINAL         |          LEARNT          | Progress |      Parameters    |\n");
    reportf("|           |    Vars  Clauses Literals |    Limit  Clauses Lit/Cl |          | VarDecay RestartInc|\n");
    reportf("====================================================================================================\n");
    }
  
  // Search:
  while (status == l_Undef){
    
    
    if((firstiteration==1) && (nLearnts()-previous_learntclauses)>clauseDiffLimit*nClauses())
      
      {
	  clauseDiffLimit*=2;
	  firstiteration=0;

	  //Restart begins: Dump CNF
	  struct svm_node *x;
	  x=FeatureGenerator(range1);

	  //previous_learntclauses=nLearnts();
	  double newVarDecay,newRestartInc;
	  
	  /*	  int i=0;
	  printf("***********Debugging Scaled Features**********\n");	 
	  while(x[i].index!=-1){
	    printf("%d:%lf ",i+1,x[i].value);
	    i++;
	  } 
	  printf("\n");  
	  */
	  int nr_class1=svm_get_nr_class(svmmodel1);
	  int nr_class2=svm_get_nr_class(svmmodel2);
	  double *prob_estimates1,*prob_estimates2;
	  int *labels1=(int *)malloc(nr_class1*sizeof(int));
	  int *labels2=(int *)malloc(nr_class2*sizeof(int));
	  svm_get_labels(svmmodel1,labels1);
	  svm_get_labels(svmmodel2,labels2);

	  prob_estimates1=(double *)malloc(nr_class1*sizeof(double));
	  prob_estimates2=(double *)malloc(nr_class2*sizeof(double));
	  
	  
	  int predictedDecay=(int)svm_predict(svmmodel1,x);
	  int predictedRestartInc=(int)svm_predict(svmmodel2,x);

	  // Rename predictedDecay1 back to predictedDecay for only probability estimates
	  int predictedDecay1=(int)svm_predict_probability(svmmodel1,x,prob_estimates1);
	  int predictedRestartInc1=(int)svm_predict_probability(svmmodel2,x,prob_estimates2);

	  double maxdecayprob=-1,maxrestartprob=-1;
	  
	    for(int i=0;i<nr_class1;i++)
	      if(labels1[i]==predictedDecay)
		maxdecayprob=prob_estimates1[i];
	    //for(int i=0;i<nr_class1;i++)
	    //if(maxdecayprob<prob_estimates1[i])
	    //  maxdecayprob=prob_estimates1[i];
	  
	    
	    for(int i=0;i<nr_class2;i++)
	      if(labels2[i]==predictedRestartInc)
		maxrestartprob=prob_estimates2[i];
	    
	    //for(int i=0;i<nr_class2;i++)
	    //if(maxrestartprob<prob_estimates2[i])
	    //  maxrestartprob=prob_estimates2[i];
	  
	  /* for(int i=0;i<nr_class1;i++)
	    {
	      printf("class label=%d  prob_estimate1[%d]=%lf ",labels1[i],i,prob_estimates1[i]);
	    }
	  
	  printf("\n");
	  for(int i=0;i<nr_class2;i++)
	    {
	      printf("class label=%d  prob_estimate2[%d]=%lf ",labels2[i],i,prob_estimates2[i]);
	    }
	  */
  
	  newVarDecay=possibleDecays[predictedDecay-1];
	  
	  newRestartInc=possibleRestarts[predictedRestartInc-1];

	  // var_decay=(1/(newVarDecay));
	   
	  //restart_inc=newRestartInc;
	  
	

	  /*AND of thresholds */

	  printf("=======================================[ Correcting Course ]========================================\n");


	  if(maxdecayprob>THRESHOLD_DECAY && maxrestartprob>THRESHOLD_RESTART)
	    {
	      printf("  Changing decay with probability = %10.5lf\n",maxdecayprob);
	      var_decay=(1/(newVarDecay));
	      printf("  Changing restart-inc with probability = %10.5lf\n",maxrestartprob);
	      restart_inc=newRestartInc;
	    }
	  else
	    {
	      printf("  Not changing decay as probability=%10.5lf\n",maxdecayprob);
	      printf("  Not changing restart-inc as probability=%10.5lf\n",maxrestartprob);
	    }
	  printf("====================================================================================================\n");
	 
	  
	  //restart_inc=1.5;
	  

	  /* OR model for thresholds */

	  /*	  if(maxdecayprob>THRESHOLD_DECAY)
	    {
	      printf("\nChanging decay with probability = %lf\n",maxdecayprob);
	      var_decay=(1/(newVarDecay));
	     	     
	    }
	  else
	    {
	      printf("\nNot changing decay as probability=%lf\n",maxdecayprob);
	     
	    }
	  
	  if(maxrestartprob>THRESHOLD_RESTART)
	    {
	      printf("\nChanging restart-inc with probability = %lf\n",maxrestartprob);
	      restart_inc=newRestartInc;
	    }
	  else
	    {
	      printf("\nNot changing restart-inc as probability=%lf\n",maxrestartprob);
	    }
	  */
	 
	}
         
        if (verbosity >= 1)
            reportf("| %9d | %7d %8d %8d | %8d %8d %6.0f | %6.3f %% |  %5.4f    %5.2f   |\n", (int)conflicts, order_heap.size(), nClauses(), (int)clauses_literals, (int)nof_learnts, nLearnts(), (double)learnts_literals/nLearnts(), progress_estimate*100,var_decay, restart_inc), fflush(stdout);
        status = search((int)nof_conflicts, (int)nof_learnts);
        nof_conflicts *= restart_inc;
        nof_learnts   *= learntsize_inc;
    }

    if (verbosity >= 1)
        reportf("===============================================================================\n");


    if (status == l_True){
        // Extend & copy model:
        model.growTo(nVars());
        for (int i = 0; i < nVars(); i++) model[i] = value(i);
#ifndef NDEBUG
        verifyModel();
#endif
    }else{
        assert(status == l_False);
        if (conflict.size() == 0)
            ok = false;
    }

    cancelUntil(0);
    return status == l_True;
}

//=================================================================================================
// Debug methods:


void Solver::verifyModel()
{
    bool failed = false;
    for (int i = 0; i < clauses.size(); i++){
        assert(clauses[i]->mark() == 0);
        Clause& c = *clauses[i];
        for (int j = 0; j < c.size(); j++)
            if (modelValue(c[j]) == l_True)
                goto next;

        reportf("unsatisfied clause: ");
        printClause(*clauses[i]);
        reportf("\n");
        failed = true;
    next:;
    }

    assert(!failed);

    reportf("Verified %d original clauses.\n", clauses.size());
}


void Solver::checkLiteralCount()
{
    // Check that sizes are calculated correctly:
    int cnt = 0;
    for (int i = 0; i < clauses.size(); i++)
        if (clauses[i]->mark() == 0)
            cnt += clauses[i]->size();

    if ((int)clauses_literals != cnt){
        fprintf(stderr, "literal count: %d, real value = %d\n", (int)clauses_literals, cnt);
        assert((int)clauses_literals == cnt);
    }
}
