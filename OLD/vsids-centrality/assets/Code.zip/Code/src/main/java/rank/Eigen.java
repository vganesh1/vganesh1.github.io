package rank;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import static java.lang.Math.*;
import java.util.concurrent.atomic.AtomicInteger;

public class Eigen {

    public static int find(int val, int[] array, int from, int to) {
        for (int i = from; i < to; i++) {
            if (array[i] == val) {
                return i;
            }
        }
        return -1;
    }

    public static double nChoose2(double n) {
        return (n * (n - 1)) / 2;
    }

    public static int[][] readDimacs(Reader in, AtomicInteger vars) throws IOException {
        return readDimacs(new BufferedReader(in), vars);
    }

    public static int[][] readDimacs(BufferedReader in, AtomicInteger vars) throws IOException {
        List<int[]> clauses = new ArrayList<int[]>(1024);
        String line;
        int n = 0;
        while ((line = in.readLine()) != null) {
            line = line.trim();
            if (line.length() != 0) {
                if (!line.startsWith("p") && !line.startsWith("c")) {
                    String[] literals = line.split(" ");
                    if (!literals[literals.length - 1].equals("0")) {
                        throw new IllegalStateException("Expected line to be terminated by 0");
                    }

                    int[] clause = new int[literals.length - 1];
                    for (int i = 0; i < literals.length - 1; i++) {
                        int lit = Integer.parseInt(literals[i]);
                        clause[i] = lit;
                        n = Math.max(n, abs(lit));
                    }

                    clauses.add(clause);
                }
            }
        }
        vars.set(n);
        return clauses.toArray(new int[clauses.size()][]);
    }

    public static void printDimacs(int[][] clauses, int vars, Writer out) throws IOException {
        out.write("p cnf ");
        out.write(Integer.toString(vars));
        out.write(' ');
        out.write(Integer.toString(clauses.length));
        out.write(System.lineSeparator());
        for (int[] clause : clauses) {
            for (int lit : clause) {
                out.write(Integer.toString(lit));
                out.write(' ');
            }
            out.write('0');
            out.write(System.lineSeparator());
        }
        out.flush();
    }

    public static int[][] sortClause(int[][] clauses, final double[] centrality) throws IOException {
        final double[] clauseCentrality = new double[clauses.length];
        for (int i = 0; i < clauses.length; i++) {
            double sum = 0;
            for (int lit : clauses[i]) {
                sum += centrality[abs(lit) - 1];
            }
            clauseCentrality[i] = sum / clauses[i].length;
        }
        Integer[] vars = new Integer[clauses.length];
        for (int i = 0; i < vars.length; i++) {
            vars[i] = i;
        }
        Arrays.sort(vars, new Comparator<Integer>() {
            public int compare(Integer o1, Integer o2) {
                return Double.compare(clauseCentrality[o2], clauseCentrality[o1]);
            }
        });
        int[][] sortedClauses = new int[clauses.length][];
        for (int i = 0; i < vars.length; i++) {
            sortedClauses[i] = clauses[vars[i]];
        }
        return sortedClauses;
    }

    public static void mapLit(int[][] clauses, int[] mapping) throws IOException {
        Comparator<Integer> abs = new Comparator<Integer>() {
            public int compare(Integer o1, Integer o2) {
                return Integer.compare(Math.abs(o1), Math.abs(o2));
            }
        };
        for (int[] c : clauses) {
            Integer[] clause = new Integer[c.length];
            for (int i = 0; i < c.length; i++) {
                int lit = c[i];
                clause[i] = lit > 0
                        ? mapping[lit - 1] + 1
                        : -mapping[-lit - 1] - 1;
            }
            Arrays.sort(clause, abs);
            for (int i = 0; i < c.length; i++) {
                c[i] = clause[i];
            }
        }
    }

    public static double[] approxEigenvectorCentrality(int[][] clauses) throws IOException {
        int n = 0;
        int[][] edges = new int[1024][16];
        double[][] matrix = new double[1024][16];
        int[] size = new int[1024];

        for (int[] c : clauses) {
            int[] clause = new int[c.length];
            for (int i = 0; i < c.length; i++) {
                clause[i] = Math.abs(c[i]);
                n = Math.max(n, clause[i]);
            }
            if (n > matrix.length) {
                int l = matrix.length;
                size = Arrays.copyOf(size, n * 2 + 1);
                edges = Arrays.copyOf(edges, n * 2 + 1);
                matrix = Arrays.copyOf(matrix, n * 2 + 1);
                Arrays.fill(edges, l, edges.length, new int[0]);
                Arrays.fill(matrix, l, matrix.length, new double[0]);
            }

            double numEdges = nChoose2(clause.length);
            for (int i = 0; i < clause.length; i++) {
                for (int j = i + 1; j < clause.length; j++) {
                    int var1 = clause[i] - 1;
                    int var2 = clause[j] - 1;

                    int index1 = find(var2, edges[var1], 0, size[var1]);
                    if (index1 == -1) {
                        if (size[var1] == edges[var1].length) {
                            edges[var1] = Arrays.copyOf(edges[var1], edges[var1].length * 2 + 1);
                            matrix[var1] = Arrays.copyOf(matrix[var1], matrix[var1].length * 2 + 1);
                        }
                        index1 = size[var1];
                        edges[var1][index1] = var2;
                        size[var1]++;
                    }
                    matrix[var1][index1] += 1 / numEdges;

                    int index2 = find(var1, edges[var2], 0, size[var2]);
                    if (index2 == -1) {
                        if (size[var2] == edges[var2].length) {
                            edges[var2] = Arrays.copyOf(edges[var2], edges[var2].length * 2 + 1);
                            matrix[var2] = Arrays.copyOf(matrix[var2], matrix[var2].length * 2 + 1);
                        }
                        index2 = size[var2];
                        edges[var2][index2] = var1;
                        size[var2]++;
                    }
                    matrix[var2][index2] += 1 / numEdges;
                }
            }
        }
        return approxEigenvectorCentrality(edges, matrix, n, size);
    }

    public static double[] approxEigenvectorCentrality(int[][] edges, double[][] matrix, int n, int[] size) {
        double[] value = new double[n];
        Arrays.fill(value, 1);
        for (int repeat = 0; repeat < 500; repeat++) {
            double[] w = new double[n];
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < size[i]; j++) {
                    w[edges[i][j]] += matrix[i][j] * value[i];
                }
            }
            double sum = 0;
            for (double v : w) {
                sum += v * v;
            }
            sum = Math.sqrt(sum);
            for (int i = 0; i < w.length; i++) {
                w[i] /= sum;
            }
            value = w;
        }
        return value;
    }
}
