/**
 * Various heuristics to select the next variable to branch on.
 */

package org.sat4j.minisat.orders;

