/**
 * Implementation of an explanation engine in case of unsatisfiability.
 */

package org.sat4j.tools.xplain;

