package rank;

/**
 *
 * @author jimmy
 */
public class Stats {

    public static double mean(double[] data) {
        double sum = 0.0;
        for (double a : data) {
            sum += a;
        }
        return sum / (double) data.length;
    }

    public static double variance(double[] data) {
        double mean = mean(data);
        double temp = 0;
        for (double a : data) {
            temp += (mean - a) * (mean - a);
        }
        return temp / (double) data.length;
    }

    public static double stdDev(double[] data) {
        return Math.sqrt(variance(data));
    }
}
