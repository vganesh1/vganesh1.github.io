/**
 * Contains a command line launcher for the SAT solvers.
 */

package org.sat4j;

