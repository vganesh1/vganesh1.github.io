package rank;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import static org.sat4j.core.LiteralsUtils.*;
import org.sat4j.minisat.core.Constr;
import org.sat4j.minisat.core.Solver;
import org.sat4j.specs.IConstr;
import org.sat4j.specs.IVec;

/**
 *
 * @author jimmy
 */
public class Dimacs {

    public static double score(double n) {
        return n - 1;
    }

    public static Graph tvig(Solver solver, double decay, boolean includeOriginals) {
        double temporal = 1e25;
        Graph graph = new Graph();
        graph.setNumNodes(solver.nVars());
        IVec<Constr> clauses = solver.getLearnedConstraints();
        for (int i = clauses.size() - 1; i >= 0 && temporal > 1e-25; i--) {
            Constr clause = clauses.get(i);
            double numEdges = score(clause.size());
            for (int j = 0; j < clause.size(); j++) {
                for (int k = j + 1; k < clause.size(); k++) {
                    int var1 = Math.abs(var(clause.get(j))) - 1;
                    int var2 = Math.abs(var(clause.get(k))) - 1;
                    graph.addEdge(var1, var2, temporal / numEdges);
                }
            }
            temporal /= decay;
        }
        if (includeOriginals && temporal > 1e-25) {
            for (int i = 0; i < solver.nConstraints(); i++) {
                IConstr clause = solver.getIthConstr(i);
                double numEdges = score(clause.size());
                for (int j = 0; j < clause.size(); j++) {
                    for (int k = j + 1; k < clause.size(); k++) {
                        int var1 = Math.abs(var(clause.get(j))) - 1;
                        int var2 = Math.abs(var(clause.get(k))) - 1;
                        graph.addEdge(var1, var2, temporal / numEdges);
                    }
                }
            }
        }
        return graph;
    }

    public static Graph vig(Solver solver, boolean includeOriginals) {
        Graph graph = new Graph();
        graph.setNumNodes(solver.nVars());
        IVec<Constr> clauses = solver.getLearnedConstraints();
        for (int i = 0; i < clauses.size(); i++) {
            Constr clause = clauses.get(i);
            double numEdges = score(clause.size());
            for (int j = 0; j < clause.size(); j++) {
                for (int k = j + 1; k < clause.size(); k++) {
                    int var1 = Math.abs(var(clause.get(j))) - 1;
                    int var2 = Math.abs(var(clause.get(k))) - 1;
                    graph.addEdge(var1, var2, 1.0 / numEdges);
                }
            }
        }
        if (includeOriginals) {
            for (int i = 0; i < solver.nConstraints(); i++) {
                IConstr clause = solver.getIthConstr(i);
                double numEdges = score(clause.size());
                for (int j = 0; j < clause.size(); j++) {
                    for (int k = j + 1; k < clause.size(); k++) {
                        int var1 = Math.abs(var(clause.get(j))) - 1;
                        int var2 = Math.abs(var(clause.get(k))) - 1;
                        graph.addEdge(var1, var2, 1.0 / numEdges);
                    }
                }
            }
        }
        return graph;
    }

    public static int[][] readDimacs(Reader in, AtomicInteger vars) throws IOException {
        return readDimacs(new BufferedReader(in), vars);
    }

    public static int[][] readDimacs(BufferedReader in, AtomicInteger vars) throws IOException {
        List<int[]> clauses = new ArrayList<int[]>(1024);
        String line;
        int n = 0;
        while ((line = in.readLine()) != null) {
            line = line.trim();
            if (line.length() != 0) {
                if (!line.startsWith("p") && !line.startsWith("c")) {
                    String[] literals = line.split(" ");
                    if (!literals[literals.length - 1].equals("0")) {
                        throw new IllegalStateException("Expected line to be terminated by 0");
                    }

                    int[] clause = new int[literals.length - 1];
                    for (int i = 0; i < literals.length - 1; i++) {
                        int lit = Integer.parseInt(literals[i]);
                        clause[i] = lit;
                        n = Math.max(n, Math.abs(lit));
                    }

                    clauses.add(clause);
                }
            }
        }
        vars.set(n);
        return clauses.toArray(new int[clauses.size()][]);
    }

    public static void printDimacs(int[][] clauses, int vars, Writer out) throws IOException {
        out.write("p cnf ");
        out.write(Integer.toString(vars));
        out.write(' ');
        out.write(Integer.toString(clauses.length));
        out.write(System.lineSeparator());
        for (int[] clause : clauses) {
            for (int lit : clause) {
                out.write(Integer.toString(lit));
                out.write(' ');
            }
            out.write('0');
            out.write(System.lineSeparator());
        }
        out.flush();
    }

    public static Graph variableIncidenceGraph(int[][] clauses) {
        Graph graph = new Graph();
        for (int[] clause : clauses) {
            double numEdges = score(clause.length);
            for (int i = 0; i < clause.length; i++) {
                for (int j = i + 1; j < clause.length; j++) {
                    int var1 = Math.abs(clause[i]) - 1;
                    int var2 = Math.abs(clause[j]) - 1;

                    graph.addEdge(var1, var2, 1.0f / numEdges);
                }
            }
        }
        return graph;
    }
}
