package rank;

import gnu.trove.list.array.TDoubleArrayList;
import gnu.trove.set.hash.TIntHashSet;
import java.io.File;
import java.io.FileInputStream;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.math3.stat.correlation.PearsonsCorrelation;
import org.apache.commons.math3.stat.correlation.SpearmansCorrelation;
import org.sat4j.core.LiteralsUtils;
import org.sat4j.minisat.SolverFactory;
import org.sat4j.minisat.core.ILits;
import org.sat4j.minisat.core.SearchParams;
import org.sat4j.minisat.core.Solver;
import org.sat4j.minisat.core.Solver.VSIDS;
import org.sat4j.minisat.orders.VarOrderHeap;
import org.sat4j.reader.DimacsReader;
import org.sat4j.reader.InstanceReader;
import org.sat4j.reader.Reader;
import org.sat4j.specs.TimeoutException;
import org.sat4j.tools.SearchListenerAdapter;

/**
 *
 * @author jimmy
 */
public class Benchmark {

    public static double[] drop(double[] values, int drop) {
        assert drop >= 0;
        return Arrays.copyOfRange(values, drop, values.length);
    }

    public static int[] top(final double[] ranks) {
        Integer[] placement = new Integer[ranks.length];
        for (int i = 0; i < placement.length; i++) {
            placement[i] = i;
        }
        Arrays.sort(placement, new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return Double.compare(ranks[o2], ranks[o1]);
            }
        });
        int[] top = new int[placement.length];
        for (int i = 0; i < top.length; i++) {
            top[i] = placement[i];
        }
        return top;
    }

    public static double sum(double[] values) {
        double sum = 0;
        for (double value : values) {
            sum += value;
        }
        return sum;
    }

    public static void main(String[] args) throws Exception {
        final boolean decay = Boolean.parseBoolean(args[0]);
        final boolean temporal = Boolean.parseBoolean(args[1]);
        final boolean includeOriginals = Boolean.parseBoolean(args[2]);
        final VSIDS vsids = VSIDS.values()[Integer.parseInt(args[3])];
        final boolean tec = Boolean.parseBoolean(args[4]);
        final boolean deleteClauses = Boolean.parseBoolean(args[5]);
        final boolean zeroSeed = Boolean.parseBoolean(args[6]);
        final String file = args[7];

        final Solver solver = (Solver) SolverFactory.newDefault();
        Solver.vsids = vsids;
        SearchParams params = new SearchParams();
        if (decay) {
            System.out.println("c Yesdecay");
        } else {
            params.setVarDecay(1);
            System.out.println("c Nodecay");
        }
        System.out.println("c " + (temporal ? "Temporal" : "Nottemporal"));
        System.out.println("c " + (includeOriginals ? "YesOriginals" : "NoOriginals"));
        System.out.println("c " + vsids);
        System.out.println("c " + (tec ? "TEC" : "Degree centrality"));
        System.out.println("c " + (deleteClauses ? "Yes deletion" : "No deletion"));
        System.out.println("c " + (zeroSeed ? "No seed" : "Yes Seed"));

        solver.setSearchParams(params);
        Reader r = new InstanceReader(solver);
        r.parseInstance(file);

        System.out.println("c variables " + solver.nVars());
        System.out.println("c constraints " + solver.nConstraints());

        solver.setDBSimplificationAllowed(deleteClauses);
        solver.setTimeout(5000);
        Solver.delete = deleteClauses;

        solver.setSearchListener(new SearchListenerAdapter() {
            double decay;
            BigInteger decisionLevels = BigInteger.ZERO;
            long loops = 0;

            @Override
            public void beginLoop() {
                decisionLevels
                        = decisionLevels.add(BigInteger.valueOf(solver.decisionLevel()));
                if (loops == 0) {
                    decay = 1.0 / 0.95; // Same as Sat4j

                    if (!zeroSeed) {
                        Graph graph = Dimacs.vig(solver, includeOriginals);
                        double[] eigen = tec
                                ? graph.approxEigenvectorCentrality()
                                : graph.weightedDegreeCentrality();
                        VarOrderHeap order = (VarOrderHeap) solver.getOrder();
                        for (int i = 1; i <= solver.nVars(); i++) {
                            order.increaseVarTo(i, eigen[i-1]);
                        }
                        order.varDecayActivity();
                    }
                }
                loops++;
                if (loops % 1000 == 0) {
                    computeCentrality();
                }
            }

            private void computeCentrality() {
                Graph graph = temporal
                        ? Dimacs.tvig(solver, decay, includeOriginals)
                        : Dimacs.vig(solver, includeOriginals);
                double[] eigen = tec
                        ? graph.approxEigenvectorCentrality()
                        : graph.weightedDegreeCentrality();
                int[] topEigen = top(eigen);
                double[] activity = drop(solver.getOrder().getVariableHeuristics(),
                        /*Activity index 0 is not used.*/ 1);
                int[] topActivity = top(activity);

                ILits l = solver.getVocabulary();

                int eigenZero = 0;
                int activityZero = 0;

                TDoubleArrayList unassignedEigen = new TDoubleArrayList();
                TDoubleArrayList unassignedActivity = new TDoubleArrayList();

                int taUnassigned = -1;
                TIntHashSet ta100 = new TIntHashSet();
                for (int i = 0; i < topActivity.length && ta100.size() < 100; i++) {
                    int ta = topActivity[i] + 1;

                    if (l.isUnassigned(LiteralsUtils.posLit(ta))) {
                        if (ta100.isEmpty()) {
                            taUnassigned = ta;
                        }
                        if (ta100.size() < 100) {
                            ta100.add(ta);
                        }
                    }
                }
                if (taUnassigned == -1) {
                    throw new Error();
                }

                int unassigned = 0;
                TIntHashSet te100 = new TIntHashSet();
                int taRankInE = 1;
                for (int i = 0; i < topEigen.length; i++) {
                    int te = topEigen[i] + 1;
                    if (l.isUnassigned(LiteralsUtils.posLit(te))) {
                        if (te100.size() < 100) {
                            te100.add(te);
                        }
                        if (eigen[taUnassigned - 1] < eigen[te - 1]) {
                            taRankInE++;
                        }
                    }
                }
                TIntHashSet te100a = new TIntHashSet(te100);

                for (int i = 0; i < eigen.length; i++) {
                    int var = i + 1;
                    if (eigen[i] == 0) {
                        eigenZero++;
                    }
                    if (activity[i] == 0) {
                        activityZero++;
                    }
                    if (l.isUnassigned(LiteralsUtils.posLit(var))) {
                        unassigned++;
                        unassignedEigen.add(eigen[i]);
                        unassignedActivity.add(activity[i]);
                    }
                }

                te100a.retainAll(ta100);
                System.out.println(
                        "s "
                        + te100a.size() + " "
                        + decisionLevels.divide(BigInteger.valueOf(loops)) + " "
                        + (solver.getStats().propagations / solver.getStats().decisions) + " "
                        + solver.getLearnedConstraints().size() + " "
                        + taRankInE + " "
                        + unassigned + " "
                        + new SpearmansCorrelation().correlation(
                                activity, eigen) + " "
                        + new SpearmansCorrelation().correlation(
                                unassignedActivity.toArray(), unassignedEigen.toArray()) + " "
                        + new PearsonsCorrelation().correlation(
                                activity, eigen) + " "
                        + new PearsonsCorrelation().correlation(
                                unassignedActivity.toArray(), unassignedEigen.toArray())
                        + " " + eigenZero + " " + activityZero);
            }
        });

        long start = System.currentTimeMillis();
        try {
            System.out.println("c SAT " + solver.isSatisfiable());
        } catch (TimeoutException e) {
            System.out.println("c SAT timeout");
        }
        Map<String, Number> map = solver.getStat();
        for (Entry entry : map.entrySet()) {
            System.out.println("c " + entry.getKey() + " " + entry.getValue());
        }
        System.out.println("c Time " + (System.currentTimeMillis() - start));
    }

    public static void decayOrNo(String[] args) throws Exception {
        boolean decay = Boolean.parseBoolean(args[0]);
        File file = new File(args[1]);
        final Solver solver = (Solver) SolverFactory.newDefault();
        SearchParams params = new SearchParams();
        if (!decay) {
            params.setVarDecay(1);
        }
        solver.setSearchParams(params);
        DimacsReader r = new DimacsReader(solver);
        r.parseInstance(new FileInputStream(file));

        solver.setDBSimplificationAllowed(true);
        solver.setTimeout(900);

        long start = System.currentTimeMillis();
        try {
            System.out.println("SAT: " + solver.isSatisfiable());
        } catch (TimeoutException e) {
            System.out.println("SAT: timeout");
        }
        System.out.println("Decay: " + decay);
        Map<String, Number> map = solver.getStat();
        for (Entry entry : map.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
        System.out.println("Time: " + (System.currentTimeMillis() - start));
    }
}
