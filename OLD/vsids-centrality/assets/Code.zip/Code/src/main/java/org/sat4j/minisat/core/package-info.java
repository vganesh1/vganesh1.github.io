/**
 * Implementation of the MiniSAT solver skeleton.
 * 
 * This is the place to go for looking more deeply into a SAT solver.
 * All of the abstractions needed to customize a solver are defined here.
 */

package org.sat4j.minisat.core;

