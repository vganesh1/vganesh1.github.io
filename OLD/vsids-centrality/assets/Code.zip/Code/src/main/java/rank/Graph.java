package rank;

import gnu.trove.TDoubleCollection;
import gnu.trove.iterator.TDoubleIterator;
import gnu.trove.iterator.TIntDoubleIterator;
import java.util.Arrays;

/**
 *
 * @author jimmy
 */
public class Graph {

    private Node[] nodes = new Node[1024];
    private int numNodes = 0;

    public Graph() {
        for (int i = 0; i < nodes.length; i++) {
            nodes[i] = new Node();
        }
    }

    public int getNumNodes() {
        return numNodes;
    }

    public void setNumNodes(int n) {
        if (n < numNodes) {
            throw new IllegalArgumentException();
        }
        if (n > nodes.length) {
            Node[] newNodes = new Node[n];
            System.arraycopy(nodes, 0, newNodes, 0, nodes.length);
            for (int i = nodes.length; i < newNodes.length; i++) {
                newNodes[i] = new Node();
            }
            nodes = newNodes;
        }
        numNodes = n;
    }

    public Node getNode(int num) {
        assert num < numNodes;
        return nodes[num];
    }

    public void addDirectedEdge(int from, int to, double weight) {
        int largest = Math.max(from, to);
        numNodes = Math.max(numNodes, largest + 1);
        if (largest >= nodes.length) {
            Node[] newNodes = new Node[largest * 2];
            System.arraycopy(nodes, 0, newNodes, 0, nodes.length);
            for (int i = nodes.length; i < newNodes.length; i++) {
                newNodes[i] = new Node();
            }
            nodes = newNodes;
        }

        nodes[from].addEdge(to, weight);
    }

    public void addEdge(int from, int to, double weight) {
        int largest = Math.max(from, to);
        numNodes = Math.max(numNodes, largest + 1);
        if (largest >= nodes.length) {
            Node[] newNodes = new Node[largest * 2];
            System.arraycopy(nodes, 0, newNodes, 0, nodes.length);
            for (int i = nodes.length; i < newNodes.length; i++) {
                newNodes[i] = new Node();
            }
            nodes = newNodes;
        }

        nodes[from].addEdge(to, weight);
        nodes[to].addEdge(from, weight);
    }

    private static double sum(TDoubleCollection doubles) {
        float sum = 0;
        TDoubleIterator iterator = doubles.iterator();
        while (iterator.hasNext()) {
            sum += iterator.next();
        }
        return sum;
    }

    public double[] powerIteratePageRank(double[] vector, double c) {
        double oneOverN = 1.0 / (double) numNodes;
        double noOutDegreeWeight = 0;
        double[] w = new double[numNodes];
        for (int i = 0; i < numNodes; i++) {
            double weightsSum = sum(nodes[i].getOutWeights());
            TIntDoubleIterator neighbours = nodes[i].getNeighbours();
            if (nodes[i].getOutDegree() == 0) {
                noOutDegreeWeight += oneOverN * vector[i];
            } else {
                for (int j = nodes[i].getOutDegree(); j-- > 0;) {
                    neighbours.advance();
                    double realWeight = neighbours.value() / weightsSum;
                    w[neighbours.key()] += realWeight * vector[i];
                }
            }
        }
        double randomTeleport = (1.0 - c) / (double) numNodes;
        for (int i = 0; i < numNodes; i++) {
            w[i] = randomTeleport + c * (w[i] + noOutDegreeWeight);
        }
        return w;
    }

    public double[] approxPageRank(double c) {
        double[] value = new double[numNodes];
        Arrays.fill(value, 1.0 / numNodes);
        for (int repeat = 0; repeat < 100; repeat++) {
            value = powerIteratePageRank(value, c);
        }
        return value;
    }

    public double[] powerIterate(double[] vector) {
        double[] w = new double[numNodes];
        for (int i = 0; i < numNodes; i++) {
            TIntDoubleIterator neighbours = nodes[i].getNeighbours();
            for (int j = nodes[i].getOutDegree(); j-- > 0;) {
                neighbours.advance();
                w[neighbours.key()] += neighbours.value() * vector[i];
            }
        }
        double sum = 0;
        for (double v : w) {
            sum += v * v;
        }
        sum = Math.sqrt(sum);
        if (sum != 0) {
            for (int i = 0; i < w.length; i++) {
                w[i] /= sum;
            }
        }
        return w;
    }

    public double[] approxEigenvectorCentrality() {
        double[] value = new double[numNodes];
        Arrays.fill(value, 1);
        for (int repeat = 0; repeat < 100; repeat++) {
            value = powerIterate(value);
        }
        return value;
    }

    public double[] weightedDegreeCentrality() {
        double[] value = new double[numNodes];
        for (int i = 0; i < numNodes; i++) {
            TIntDoubleIterator neighbours = nodes[i].getNeighbours();
            for (int j = nodes[i].getOutDegree(); j-- > 0;) {
                neighbours.advance();
                value[neighbours.key()] += neighbours.value();
            }
        }
        return value;
    }
}
