package rank;

import gnu.trove.TDoubleCollection;
import gnu.trove.iterator.TIntDoubleIterator;
import gnu.trove.map.hash.TIntDoubleHashMap;

/**
 *
 * @author jimmy
 */
public class Node {

    private final TIntDoubleHashMap map = new TIntDoubleHashMap();

    public double getWeight(int num) {
        assert map.containsKey(num);
        return map.get(num);
    }

    public int getOutDegree() {
        return map.size();
    }

    public TDoubleCollection getOutWeights() {
        return map.valueCollection();
    }

    public void addEdge(int to, double weight) {
        map.adjustOrPutValue(to, weight, weight);
    }

    public TIntDoubleIterator getNeighbours() {
        return map.iterator();
    }
}
