package rank;


import rank.Graph;
import java.util.Arrays;
import static org.junit.Assert.*;
import org.junit.Test;

/**
 *
 * @author jimmy
 */
public class GraphTest {

    @Test
    public void testApproxPageRank() {
        // Example from: http://www.cs.princeton.edu/~chazelle/courses/BIB/pagerank.htm
        Graph g = new Graph();
        g.addDirectedEdge(0, 1, 1);
        g.addDirectedEdge(0, 2, 1);
        g.addDirectedEdge(1, 2, 1);
        g.addDirectedEdge(2, 0, 1);
        g.addDirectedEdge(3, 2, 1);

        double[] pageRank = g.approxPageRank(0.85);

        assertEquals(1.49 / 4, pageRank[0], 0.001);
        assertEquals(0.78 / 4, pageRank[1], 0.001);
        assertEquals(1.58 / 4, pageRank[2], 0.001);
        assertEquals(0.15 / 4, pageRank[3], 0.001);
    }
}
