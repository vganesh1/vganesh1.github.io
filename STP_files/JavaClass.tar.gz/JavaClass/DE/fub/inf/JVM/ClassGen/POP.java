package DE.fub.inf.JVM.ClassGen;

/**
 * POP - Pop top operand stack word
 *
 * Stack: ..., word -> ...
 *
 * @version $Id: POP.java,v 1.2 1998/10/16 09:32:22 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class POP extends PopInstruction {
  public POP() {
    super(POP, (short)1);
  }
}

