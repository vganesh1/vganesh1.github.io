package DE.fub.inf.JVM.ClassGen;

/** 
 * D2L - Convert double to long
 * Stack: ..., value.word1, value.word2 -> ..., result.word1, result.word2
 *
 * @version $Id: D2L.java,v 1.1 1998/07/01 13:05:45 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class D2L extends Instruction {
  public D2L() {
    super(D2L, (short)1);
  }
}

