package DE.fub.inf.JVM.ClassGen;

/** 
 * MONITORENTER - Enter monitor for object
 * Stack: ..., objectref -> ...
 *
 * @version $Id: MONITORENTER.java,v 1.1 1998/07/01 13:07:48 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class MONITORENTER extends Instruction {
  public MONITORENTER() {
    super(MONITORENTER, (short)1);
  }
}

