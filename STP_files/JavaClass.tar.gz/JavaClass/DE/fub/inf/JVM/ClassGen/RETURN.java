package DE.fub.inf.JVM.ClassGen;

/** 
 * RETURN -  Return from void method
 * Stack: ... -> <empty>
 *
 * @version $Id: RETURN.java,v 1.2 1998/08/05 15:13:29 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class RETURN extends ReturnInstruction {
  public RETURN() {
    super(RETURN, 1);
  }
}

