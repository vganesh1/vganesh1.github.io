package DE.fub.inf.JVM.ClassGen;

/** 
 * DUP_X1 - Duplicate top operand stack word and put two down
 * Stack: ..., word2, word1 -> ..., word1, word2, word1
 *
 * @version $Id: DUP_X1.java,v 1.1 1998/07/01 13:06:03 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class DUP_X1 extends Instruction {
  public DUP_X1() {
    super(DUP_X1, (short)1);
  }
}

