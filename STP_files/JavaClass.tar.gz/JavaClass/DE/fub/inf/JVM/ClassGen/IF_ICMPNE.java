package DE.fub.inf.JVM.ClassGen;

/** 
 * IF_ICMPNE - Branch if int comparison doesn't succeed
 *
 * Stack: ..., value1, value2 -> ...
 *
 * @version $Id: IF_ICMPNE.java,v 1.3 1998/10/22 14:06:14 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class IF_ICMPNE extends IfInstruction {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  IF_ICMPNE() {}

  public IF_ICMPNE(InstructionHandle target) {
    super(IF_ICMPNE, target);
  }

  /**
   * @return negation of instruction
   */
  public IfInstruction negate() {
    return new IF_ICMPEQ(target);
  }
}
