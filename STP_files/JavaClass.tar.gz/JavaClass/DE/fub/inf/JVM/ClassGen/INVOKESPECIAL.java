package DE.fub.inf.JVM.ClassGen;

/** 
 * INVOKESPECIAL - Invoke instance method; special handling for superclass, private
 * and instance initialization method invocations
 *
 * Stack: ..., objectref, [arg1, [arg2 ...]] -> ...
 *
 * @version $Id: INVOKESPECIAL.java,v 1.2 1998/07/29 19:50:38 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class INVOKESPECIAL extends InvokeInstruction {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  INVOKESPECIAL() {}

  public INVOKESPECIAL(int index) {
    super(INVOKESPECIAL, index);
  }
}

