package DE.fub.inf.JVM.ClassGen;

/** 
 * LXOR - Bitwise XOR long
 * Stack: ..., value1, value2 -> ..., result
 *
 * @version $Id: LXOR.java,v 1.1 1998/07/23 10:28:24 dahm Exp $
 * @authXOR  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class LXOR extends Instruction {
  public LXOR() {
    super(LXOR, (short)1);
  }
}

