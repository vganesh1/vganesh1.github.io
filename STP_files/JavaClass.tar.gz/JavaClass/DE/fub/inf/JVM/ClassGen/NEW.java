package DE.fub.inf.JVM.ClassGen;
import java.io.*;

/** 
 * NEW - Create new object
 * Stack: ... -> ..., objectref
 *
 * @version $Id: NEW.java,v 1.2 1998/07/29 19:50:46 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class NEW extends CPInstruction implements LoadClass {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  NEW() {}

  public NEW(int index) {
    super(NEW, index);
  }
}

