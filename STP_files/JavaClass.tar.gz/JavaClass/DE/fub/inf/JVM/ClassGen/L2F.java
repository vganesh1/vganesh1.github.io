package DE.fub.inf.JVM.ClassGen;

/**
 * L2F - Convert long to float
 * Stack: ..., value.word1, value.word2 -> ..., result
 *
 * @version $Id: L2F.java,v 1.1 1998/07/01 13:07:22 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class L2F extends Instruction {
  public L2F() {
    super(L2F, (short)1);
  }
}

