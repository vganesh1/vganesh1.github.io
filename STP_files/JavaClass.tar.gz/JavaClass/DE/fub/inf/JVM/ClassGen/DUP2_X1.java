package DE.fub.inf.JVM.ClassGen;

/** 
 * DUP2_X1 - Duplicate two top operand stack words and put three down
 * Stack: ..., word3, word2, word1 -> ..., word2, word1, word3, word2, word1
 *
 * @version $Id: DUP2_X1.java,v 1.1 1998/07/01 13:06:01 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class DUP2_X1 extends Instruction {
  public DUP2_X1() {
    super(DUP2_X1, (short)1);
  }
}

