package DE.fub.inf.JVM.ClassGen;

/** 
 * IF_ICMPEQ - Branch if int comparison succeeds
 *
 * Stack: ..., value1, value2 -> ...
 *
 * @version $Id: IF_ICMPEQ.java,v 1.3 1998/10/22 14:06:11 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class IF_ICMPEQ extends IfInstruction {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  IF_ICMPEQ() {}

  public IF_ICMPEQ(InstructionHandle target) {
    super(IF_ICMPEQ, target);
  }

  /**
   * @return negation of instruction
   */
  public IfInstruction negate() {
    return new IF_ICMPNE(target);
  }
}
