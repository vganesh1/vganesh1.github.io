package DE.fub.inf.JVM.ClassGen;

/**
 * ISHR - Arithmetic shift right int
 * Stack: ..., value1, value2 -> ..., result
 *
 * @version $Id: ISHR.java,v 1.1 1998/07/01 13:07:11 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class ISHR extends Instruction {
  public ISHR() {
    super(ISHR, (short)1);
  }
}

