package DE.fub.inf.JVM.ClassGen;

/** 
 * IFNE - Branch if int comparison with zero succeeds
 *
 * Stack: ..., value -> ...
 *
 * @version $Id: IFNE.java,v 1.3 1998/10/22 14:06:07 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class IFNE extends IfInstruction {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  IFNE() {}

  public IFNE(InstructionHandle target) {
    super(IFNE, target);
  }

  /**
   * @return negation of instruction
   */
  public IfInstruction negate() {
    return new IFEQ(target);
  }
}
