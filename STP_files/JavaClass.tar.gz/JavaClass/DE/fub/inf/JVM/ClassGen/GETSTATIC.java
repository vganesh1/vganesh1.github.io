package DE.fub.inf.JVM.ClassGen;

/** 
 * GETSTATIC - Fetch static field from class
 * Stack: ..., -> ..., value
 * OR
 * Stack: ..., -> ..., value.word1, value.word2
 *
 * @version $Id: GETSTATIC.java,v 1.3 1998/10/16 09:32:16 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class GETSTATIC extends FieldInstruction implements PushInstruction {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  GETSTATIC() {}

  public GETSTATIC(int index) {
    super(GETSTATIC, index);
  }
}

