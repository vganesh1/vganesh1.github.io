package DE.fub.inf.JVM.ClassGen;

/** 
 * LRETURN -  Return long from method
 * Stack: ..., value.word1, value.word2 -> <empty>
 *
 * @version $Id: LRETURN.java,v 1.2 1998/08/05 15:13:25 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class LRETURN extends ReturnInstruction {
  public LRETURN() {
    super(LRETURN, 1);
  }
}

