package DE.fub.inf.JVM.ClassGen;

/** 
 * D2F - Convert double to float
 * Stack: ..., value.word1, value.word2 -> ..., result
 *
 * @version $Id: D2F.java,v 1.1 1998/07/01 13:05:43 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class D2F extends Instruction {
  public D2F() {
    super(D2F, (short)1);
  }
}

