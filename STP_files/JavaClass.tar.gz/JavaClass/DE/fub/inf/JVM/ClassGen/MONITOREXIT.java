package DE.fub.inf.JVM.ClassGen;

/** 
 * MONITOREXIT - Exit monitor for object
 * Stack: ..., objectref -> ...
 *
 * @version $Id: MONITOREXIT.java,v 1.1 1998/07/01 13:07:49 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class MONITOREXIT extends Instruction {
  public MONITOREXIT() {
    super(MONITOREXIT, (short)1);
  }
}

