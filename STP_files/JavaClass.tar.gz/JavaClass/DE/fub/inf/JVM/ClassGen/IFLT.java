package DE.fub.inf.JVM.ClassGen;

/** 
 * IFLT - Branch if int comparison with zero succeeds
 *
 * Stack: ..., value -> ...
 *
 * @version $Id: IFLT.java,v 1.3 1998/10/22 14:06:07 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class IFLT extends IfInstruction {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  IFLT() {}

  public IFLT(InstructionHandle target) {
    super(IFLT, target);
  }

  /**
   * @return negation of instruction
   */
  public IfInstruction negate() {
    return new IFGE(target);
  }
}
