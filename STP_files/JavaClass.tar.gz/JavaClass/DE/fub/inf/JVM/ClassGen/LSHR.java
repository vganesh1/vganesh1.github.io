package DE.fub.inf.JVM.ClassGen;

/** 
 * LSHR - Arithmetic shift right long
 * Stack: ..., value1, value2 -> ..., result
 *
 * @version $Id: LSHR.java,v 1.1 1998/07/01 13:07:42 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class LSHR extends Instruction {
  public LSHR() {
    super(LSHR, (short)1);
  }
}

