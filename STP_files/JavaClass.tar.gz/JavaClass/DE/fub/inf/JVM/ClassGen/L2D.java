package DE.fub.inf.JVM.ClassGen;

/** 
 * L2D - Convert long to double
 * Stack: ..., value.word1, value.word2 -> ..., result.word1, result.word2
 *
 * @version $Id: L2D.java,v 1.1 1998/07/01 13:07:21 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class L2D extends Instruction {
  public L2D() {
    super(L2D, (short)1);
  }
}

