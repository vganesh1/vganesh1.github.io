package DE.fub.inf.JVM.ClassGen;

import DE.fub.inf.JVM.Constants;
import DE.fub.inf.JVM.JavaClass.*;


/** 
 * This class represents an exception handler, i.e. specifies the  region where
 * a handler is active and an instruction where the actual handling is done.
 * pool as parameters.
 *
 * @version $Id: CodeExceptionGen.java,v 1.1 1998/08/26 09:06:13 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 * @see     MethodGen
 * @see     CodeException
 */
public final class CodeExceptionGen {
  private InstructionHandle start_pc;
  private InstructionHandle end_pc;
  private InstructionHandle handler_pc;
  private String catch_type;
  
  /**
   * Add an exception handler, i.e. specify region where a handler is active and an
   * instruction where the actual handling is done.
   *
   * @param start_pc Start of region
   * @param end_pc End of region
   * @param handler_pc Where handling is done
   * @param catch_type which exception is handled (fully qualified class name)
   */
  public CodeExceptionGen(InstructionHandle start_pc, InstructionHandle end_pc,
			  InstructionHandle handler_pc, String catch_type) {
    this.start_pc   = start_pc;
    this.end_pc     = end_pc;
    this.handler_pc = handler_pc;
    this.catch_type = catch_type;
  }

  /**
   * Get CodeException object.
   *
   * This relies on that the instruction list has already been dumped to byte code or
   * or that the `setPositions' methods has been called for the instruction list.
   *
   * @param cp constant pool
   */
  public CodeException getCodeException(ConstantPoolGen cp) {
    return new CodeException(start_pc.getInstruction().getPosition(),
			     end_pc.getInstruction().getPosition(),
			     handler_pc.getInstruction().getPosition(),
			     (catch_type == null)? 0 : cp.addClass(catch_type));
  }

  public void              setStartPC(InstructionHandle start_pc)     { this.start_pc = start_pc; }
  public InstructionHandle getStartPC()                               { return start_pc; }
  public void              setEndPC(InstructionHandle end_pc)         { this.end_pc = end_pc; }
  public InstructionHandle getEndPC()                                 { return end_pc; }
  public void              setHandlerPC(InstructionHandle handler_pc) { this.handler_pc = handler_pc; }
  public InstructionHandle getHandlerPC()                             { return handler_pc; }
  public void              setCatchType(String catch_type)            { this.catch_type = catch_type; }
  public String            getCatchType()                             { return catch_type; }

}
