package DE.fub.inf.JVM.ClassGen;
import java.io.*;
import DE.fub.inf.JVM.Util.ByteSequence;

/** 
 * MULTIANEWARRAY - Create new mutidimensional array of references
 * Stack: ..., count1, [count2, ...] -> ..., arrayref
 *
 * @version $Id: MULTIANEWARRAY.java,v 1.4 1998/08/14 16:56:17 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class MULTIANEWARRAY extends CPInstruction implements LoadClass {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  MULTIANEWARRAY() {}

  private short dimensions;

  public MULTIANEWARRAY(int index, short dimensions) {
    super(MULTIANEWARRAY, index);

    if(dimensions < 1)
      throw new ClassGenException("Invalid dimensions value: " + dimensions);

    this.dimensions = dimensions;
    length = 4;
  }

  /**
   * Dump instruction as byte code to stream out.
   * @param out Output stream
   */
  public void dump(DataOutputStream out) throws IOException {
    out.writeByte(tag);
    out.writeShort(index);
    out.writeByte(dimensions);
  }

  /**
   * Read needed data (i.e. no. dimension) from file.
   */
  protected void initFromFile(ByteSequence bytes, boolean wide)
       throws IOException
  {
    super.initFromFile(bytes, wide);
    dimensions = bytes.readByte();
    length     = 4;
  }

  /**
   * @return mnemonic for instruction
   */
  public String toString(boolean verbose) {
    return super.toString(verbose) + " " + index + " " + dimensions;
  }
}

