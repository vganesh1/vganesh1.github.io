package DE.fub.inf.JVM.ClassGen;

/**
 * FREM - Remainder of floats
 * Stack: ..., value1, value2 -> result
 *
 * @version $Id: FREM.java,v 1.1 1998/07/01 13:06:18 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class FREM extends Instruction {
  public FREM() {
    super(FREM, (short)1);
  }
}

