package DE.fub.inf.JVM.ClassGen;

/** 
 * DUP2 - Duplicate two top operand stack words
 * Stack: ..., word2, word1 -> ..., word2, word1, word2, word1
 *
 * @version $Id: DUP2.java,v 1.2 1998/10/16 09:32:14 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class DUP2 extends Instruction implements PushInstruction {
  public DUP2() {
    super(DUP2, (short)1);
  }
}

