package DE.fub.inf.JVM.ClassGen;

/** 
 * FLOAD - Load float from local variable
 * Stack ... -> ..., result
 *
 * @version $Id: FLOAD.java,v 1.2 1998/10/16 09:32:15 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class FLOAD extends LocalVariableInstruction implements PushInstruction {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  FLOAD() {}

  public FLOAD(int n) {
    super(FLOAD, FLOAD_0, n);
  }
}

