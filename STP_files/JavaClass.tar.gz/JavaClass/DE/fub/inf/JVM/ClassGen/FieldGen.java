package DE.fub.inf.JVM.ClassGen;

import DE.fub.inf.JVM.Constants;
import DE.fub.inf.JVM.JavaClass.*;

/** 
 * Template class for building up a field.  The only reasonable thing
 * one can do is a constant value attribute to a field which must of
 * course be compatible with to the declared type.
 *
 * @version $Id: FieldGen.java,v 1.2 1998/09/18 09:21:03 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 * @see Field
 */
public final class FieldGen implements Constants {
  private Type            type;
  private String          name;
  private ConstantPoolGen cp;
  private int             index = -1;
  private int             access_flags;

  /**
   * Declare a field. If it is a static field (access_flags & ACC_STATIC != 0) it
   * may have an initial value associated with it as defined by setInitValue().
   *
   * @param access_flags access qualifiers
   * @param type  field type
   * @param name field name
   * @param cp constant pool
   */
  public FieldGen(int access_flags, Type type, String name, ConstantPoolGen cp) {
    this.type         = type;
    this.name         = name;
    this.cp           = cp;
    this.access_flags = access_flags;
  }

  /**
   * Set (optional) initial value of field, otherwise it will be set to null/0/false
   * by the JVM automatically.
   */
  public void setInitValue(String str) { index = cp.addString(str); }
  public void setInitValue(long l)     { index = cp.addLong(l); }
  public void setInitValue(int i)      { index = cp.addInteger(i); }
  public void setInitValue(short s)    { index = cp.addInteger(s); }
  public void setInitValue(char c)     { index = cp.addInteger(c); }
  public void setInitValue(byte b)     { index = cp.addInteger(b); }
  public void setInitValue(boolean b)  { index = cp.addInteger(b? 1 : 0); }
  public void setInitValue(float f)    { index = cp.addFloat(f); }
  public void setInitValue(double d)   { index = cp.addDouble(d); }

  /**
   * Get method object.
   */
  public Field getField() {
    String      signature       = type.getSignature();
    int         name_index      = cp.addUtf8(name);
    int         signature_index = cp.addUtf8(signature);
    Attribute[] attrs           = null;

    if((index > 0) && (access_flags & ACC_STATIC) != 0) {
      Attribute[] a = { new ConstantValue(cp.addUtf8("ConstantValue"), 2, index,
					  cp.getConstantPool()) };
      attrs = a;
    }
    
    return new Field(access_flags, name_index, signature_index, attrs,
		     cp.getConstantPool());
  }

  public void   setType(Type type)   { this.type = type; }
  public Type   getType()            { return type; }
  public void   setName(String name) { this.name = name; }
  public String getName()            { return name; }
}
