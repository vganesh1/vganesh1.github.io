package DE.fub.inf.JVM.ClassGen;

/**
 * Denotes an unparameterized instruction that pops a value from the top of the stack,
 * namely POP and POP2.
 *
 * @version $Id: PopInstruction.java,v 1.1 1998/10/16 09:32:23 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>

 * @see POP
 * @see POP2
 */
public abstract class PopInstruction extends Instruction {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  PopInstruction() {}

  /**
   * @param index to constant pool
   */
  protected PopInstruction(short tag, int index) {
    super(tag, (short)index);
  }
}

