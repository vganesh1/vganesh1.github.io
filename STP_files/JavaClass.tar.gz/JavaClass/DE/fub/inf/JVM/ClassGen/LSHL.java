package DE.fub.inf.JVM.ClassGen;

/** 
 * LSHL - Arithmetic shift left long
 * Stack: ..., value1, value2 -> ..., result
 *
 * @version $Id: LSHL.java,v 1.1 1998/07/01 13:07:41 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class LSHL extends Instruction {
  public LSHL() {
    super(LSHL, (short)1);
  }
}

