package DE.fub.inf.JVM.ClassGen;

/**
 * FMUL - Multiply floats
 * Stack: ..., value1, value2 -> result
 *
 * @version $Id: FMUL.java,v 1.1 1998/07/01 13:06:16 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class FMUL extends Instruction {
  public FMUL() {
    super(FMUL, (short)1);
  }
}

