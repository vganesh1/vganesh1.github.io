package DE.fub.inf.JVM.ClassGen;

/** 
 * D2I - Convert double to int
 * Stack: ..., value.word1, value.word2 -> ..., result
 *
 * @version $Id: D2I.java,v 1.1 1998/07/01 13:05:44 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class D2I extends Instruction {
  public D2I() {
    super(D2I, (short)1);
  }
}

