package DE.fub.inf.JVM.ClassGen;

/** 
 * IFNULL - Branch if reference is not null
 *
 * Stack: ..., reference -> ...
 *
 * @version $Id: IFNULL.java,v 1.3 1998/10/22 14:06:09 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class IFNULL extends IfInstruction {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  IFNULL() {}

  public IFNULL(InstructionHandle target) {
    super(IFNULL, target);
  }

  /**
   * @return negation of instruction
   */
  public IfInstruction negate() {
    return new IFNONNULL(target);
  }
}
