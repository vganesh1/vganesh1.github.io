package DE.fub.inf.JVM.ClassGen;

/**
 * Denotes an instruction to be a variable length instruction, such as
 * GOTO, JSR, LOOKUPSWITCH and TABLESWITCH.
 *
 * @version $Id: VariableLengthInstruction.java,v 1.2 1998/10/16 09:32:26 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>

 * @see GOTO
 * @see JSR
 * @see LOOKUPSWITCH
 * @see TABLESWITCH
 */
public interface VariableLengthInstruction {}

