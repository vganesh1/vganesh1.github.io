package DE.fub.inf.JVM.ClassGen;

/**
 * LCMP - Compare longs:
 * Stack: ..., value1.word1, value1.word2, value2.word1, value2.word2 ->
 *        ..., result <= -1, 0, 1>
 *
 * @version $Id: LCMP.java,v 1.1 1998/07/01 13:07:28 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class LCMP extends Instruction {
  public LCMP() {
    super(LCMP, (short)1);
  }
}

