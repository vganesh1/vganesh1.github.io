package DE.fub.inf.JVM.ClassGen;

/**
 * BranchHandle is returned by specialized InstructionList.append() whenever a
 * BranchInstruction is appended. This is useful when the target of this
 * instruction is not known at time of creation and must be set later
 * via setTarget().
 *
 * @see InstructionHandle
 * @see Instruction
 * @see InstructionList
 * @version $Id: BranchHandle.java,v 1.3 1998/10/22 14:05:59 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class BranchHandle extends InstructionHandle {
  public BranchHandle(BranchInstruction i) { super(i); }

  protected BranchHandle() {}

  /**
   * Pass new target to instruction.
   */
  public void setTarget(InstructionHandle ih) {
    ((BranchInstruction)instruction).setTarget(ih);
  }

  /**
   * @return target of contained BranchInstruction
   */
  public InstructionHandle getTarget() {
    return ((BranchInstruction)instruction).getTarget();
  }

  public void setInstruction(Instruction i) {
    if(!(i instanceof BranchInstruction))
      throw new ClassGenException(i + " is not a BranchInstruction");
    instruction = i;
  }
}

