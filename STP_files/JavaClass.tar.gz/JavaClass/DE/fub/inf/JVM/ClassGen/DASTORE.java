package DE.fub.inf.JVM.ClassGen;

/** 
 * DASTORE -  Store into double array
 * Stack: ..., arrayref, index, value.word1, value.word2 -> ...
 *
 * @version $Id: DASTORE.java,v 1.1 1998/07/01 13:05:48 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class DASTORE extends Instruction {
  public DASTORE() {
    super(DASTORE, (short)1);
  }
}

