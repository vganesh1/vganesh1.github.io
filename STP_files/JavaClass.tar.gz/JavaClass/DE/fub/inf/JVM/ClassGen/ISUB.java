package DE.fub.inf.JVM.ClassGen;

/** 
 * ISUB - Substract ints
 * Stack: ..., value1, value2 -> result
 *
 * @version $Id: ISUB.java,v 1.1 1998/07/01 13:07:13 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class ISUB extends Instruction {
  public ISUB() {
    super(ISUB, (short)1);
  }
}

