package DE.fub.inf.JVM.ClassGen;

/** 
 * FASTORE -  Store into float array
 * Stack: ..., arrayref, index, value -> ...
 *
 * @version $Id: FASTORE.java,v 1.1 1998/07/01 13:06:10 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class FASTORE extends Instruction {
  public FASTORE() {
    super(FASTORE, (short)1);
  }
}

