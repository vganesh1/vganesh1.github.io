package DE.fub.inf.JVM.ClassGen;

/** 
 * IALOAD - Load int from array
 * Stack: ..., arrayref, index -> ..., value
 *
 * @version $Id: IALOAD.java,v 1.1 1998/07/01 13:06:35 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class IALOAD extends Instruction {
  public IALOAD() {
    super(IALOAD, (short)1);
  }
}

