package DE.fub.inf.JVM.ClassGen;

/** 
 * AASTORE -  Store into reference array
 * Stack: ..., arrayref, index, value -> ...
 *
 * @version $Id: AASTORE.java,v 1.1 1998/07/01 13:05:20 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class AASTORE extends Instruction {
  public AASTORE() {
    super(AASTORE, (short)1);
  }
}

