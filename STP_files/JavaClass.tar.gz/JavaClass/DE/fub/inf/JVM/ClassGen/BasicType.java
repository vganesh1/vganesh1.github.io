package DE.fub.inf.JVM.ClassGen;

/** 
 * Denotes basic type such as int.
 *
 * @version $Id: BasicType.java,v 1.2 1998/10/15 13:17:15 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public final class BasicType extends Type {
  /**
   * Constructor for basic types such as int, long, `void'
   *
   * @param type one of T_INT, T_BOOLEAN, ..., T_VOID
   * @see DE.fub.inf.JVM.Constants
   */
  public BasicType(byte type) {
    super(type, SHORT_TYPE_NAMES[type]);

    if((type < T_BOOLEAN) || (type > T_VOID))
      throw new ClassGenException("Invalid type: " + type);
  }

  public boolean equals(Object type) {
    return (type instanceof BasicType)? ((((BasicType)type).type) == this.type) : false;
  }
}
