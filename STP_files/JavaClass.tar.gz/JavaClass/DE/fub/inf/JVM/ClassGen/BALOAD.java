package DE.fub.inf.JVM.ClassGen;

/** 
 * BALOAD - Load byte or boolean from array
 * Stack: ..., arrayref, index -> ..., value
 *
 * @version $Id: BALOAD.java,v 1.1 1998/07/01 13:05:28 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class BALOAD extends Instruction {
  public BALOAD() {
    super(BALOAD, (short)1);
  }
}

