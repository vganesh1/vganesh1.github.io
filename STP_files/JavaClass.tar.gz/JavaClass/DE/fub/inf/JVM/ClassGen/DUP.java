package DE.fub.inf.JVM.ClassGen;

/** 
 * DUP - Duplicate top operand stack word
 * Stack: ..., word -> ..., word, word
 *
 * @version $Id: DUP.java,v 1.2 1998/10/16 09:32:13 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class DUP extends Instruction implements PushInstruction {
  public DUP() {
    super(DUP, (short)1);
  }
}

