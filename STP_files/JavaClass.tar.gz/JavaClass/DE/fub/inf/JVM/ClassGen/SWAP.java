package DE.fub.inf.JVM.ClassGen;

/** 
 * SWAP - Swa top operand stack word
 * Stack: ..., word2, word1 -> ..., word1, word2
 *
 * @version $Id: SWAP.java,v 1.1 1998/07/01 13:08:05 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class SWAP extends Instruction {
  public SWAP() {
    super(SWAP, (short)1);
  }
}

