package DE.fub.inf.JVM.ClassGen;

/** 
 * FRETURN -  Return float from method
 * Stack: ..., value -> <empty>
 *
 * @version $Id: FRETURN.java,v 1.2 1998/08/05 15:13:19 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class FRETURN extends ReturnInstruction {
  public FRETURN() {
    super(FRETURN, 1);
  }
}

