package DE.fub.inf.JVM.ClassGen;

/** 
 * DRETURN -  Return double from method
 * Stack: ..., value.word1, value.word2 -> <empty>
 *
 * @version $Id: DRETURN.java,v 1.2 1998/08/05 15:13:19 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class DRETURN extends ReturnInstruction {
  public DRETURN() {
    super(DRETURN, 1);
  }
}

