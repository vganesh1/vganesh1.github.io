package DE.fub.inf.JVM.ClassGen;

import DE.fub.inf.JVM.Constants;
import DE.fub.inf.JVM.JavaClass.*;
import java.util.Vector;

/** 
 * Template class for building up a method. This is done by defining exception
 * handlers, adding thrown exceptions, local variables and attributes, whereas
 * the `LocalVariableTable' and `LineNumberTable' attributes will be set
 * automatically for the code.
 *
 * While generating code it may be necessary to insert NOP operations. You can
 * use the `removeNOPs' method to get rid off them.
 * The resulting method object can be obtained via the `getMethod()' method.
 *
 * @version $Id: MethodGen.java,v 1.6 1998/10/15 13:17:15 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 * @see     InstructionList
 * @see     Method
 */
public final class MethodGen implements Constants {
  private String          method_name;
  private String          class_name;
  private Type            return_type;
  private Type[]          arg_types;
  private String[]        arg_names;
  private int             access_flags;
  private int             max_locals;
  private int             max_stack;
  private InstructionList il;
  private ConstantPoolGen cp;

  private Vector          variable_vec    = new Vector();
  private Vector          line_number_vec = new Vector();
  private Vector          attribute_vec   = new Vector();
  private Vector          exception_vec   = new Vector();
  private Vector          throws_vec      = new Vector();
  private Vector          code_attrs_vec  = new Vector();

  /**
   * Declare method. If the method is non-static the constructor automatically
   * declares a local variable `$this' in slot 0. The actual code is contained in the `il'
   * parameter, which may further manipulated by the user. But he must take care not to remove
   * any instruction (handles) that are still referenced from this object.
   *
   * For example one may not add a local variable and later remove the instructions it refers
   * to without causing havoc. It is safe however if you remove that local variable, too.
   *
   * @param access_flags access qualifiers
   * @param return_type  method type
   * @param arg_types argument types
   * @param arg_names argument names (if this is null, default names will be provided
   * for them)
   * @param method_name name of method
   * @param class_name class name containing this method
   * @param il instruction list associated with this method, may be null only for
   * abstract methods
   * @param cp constant pool
   */
  public MethodGen(int access_flags, Type return_type, Type[] arg_types,
		   String[] arg_names, String method_name, String class_name,
		   InstructionList il, ConstantPoolGen cp) {
    this.access_flags = access_flags;
    this.return_type  = return_type;
    this.arg_types    = arg_types;
    this.arg_names    = arg_names;
    this.method_name  = method_name;
    this.class_name   = class_name;
    this.il           = il;
    this.cp           = cp;

    if((access_flags & ACC_ABSTRACT) == 0) {
      InstructionHandle start = il.getStart();
      InstructionHandle end   = il.getEnd();

      /* Add local variables, namely the implicit `this' and the arguments
       */
      if((access_flags & ACC_STATIC) == 0) // Instance method -> `this' is local var 0
	addLocalVariable("this", new ObjectType(class_name), start, end); // Valid from start to end
    
      if(arg_types != null) {
	int size = arg_types.length;
	
	if(arg_names != null) { // Names for variables provided?
	  if(size != arg_names.length)
	    throw new ClassGenException("Mismatch in argument array lengths: " +
				      size + " vs. " + arg_names.length);
	} else { // Give them dummy names
	  arg_names = new String[size];

	  for(int i=0; i < size; i++)
	    arg_names[i] = "arg" + i;
	}

	for(int i=0; i < size; i++)
	  addLocalVariable(arg_names[i], arg_types[i], start, end);
      }
    }
  }

  /**
   * Instantiate from existing method.
   *
   * @param m method
   * @param class_name class name containing this method
   * @param cp constant pool (must contain the same entries as the method's constant pool)
   */
  public MethodGen(Method m, String class_name, ConstantPoolGen cp) {
    this(m.getAccessFlags(), Type.getReturnType(m.getSignature()),
	 Type.getArgumentTypes(m.getSignature()), null /* may be overwritten anyway */,
	 m.getName(), class_name, new InstructionList(m.getCode().getCode()), cp);

    Attribute[] attributes = m.getAttributes();
    for(int i=0; i < attributes.length; i++) {
      Attribute a = attributes[i];

      if(a instanceof Code) {
	Code c = (Code)a;
	setMaxStack(c.getMaxStack());
	setMaxLocals(c.getMaxLocals());
	
	CodeException[] ces = c.getExceptionTable();
	
	if(ces != null) {
	  for(int j=0; j < ces.length; j++) {
	    CodeException ce   = ces[j];
	    int           type = ce.getCatchType();
	    String        name = null;
	    
	    if(type > 0)
	      name = cp.getConstantPool().getConstantString(type, CONSTANT_Class);

	    addExceptionHandler(il.findHandle(ce.getStartPC()), il.findHandle(ce.getEndPC()),
				il.findHandle(ce.getHandlerPC()), name);
	  }
	}

	Attribute[] c_attributes = c.getAttributes();
	for(int j=0; j < c_attributes.length; j++) {
	  a = c_attributes[j];

	  if(a instanceof LineNumberTable) {
	    LineNumber[] ln = ((LineNumberTable)a).getLineNumberTable();
	    for(int k=0; k < ln.length; k++) {
	      LineNumber l = ln[k];
	      addLineNumber(il.findHandle(l.getStartPC()), l.getLineNumber());
	    }
	  }
	  else if (a instanceof LocalVariableTable) {
	    LocalVariable[] lv = ((LocalVariableTable)a).getLocalVariableTable();
	    for(int k=0; k < lv.length; k++) {
	      LocalVariable     l     = lv[k];
	      InstructionHandle start = il.findHandle(l.getStartPC());
	      InstructionHandle end   = il.findHandle(l.getStartPC() + l.getLength());

	      // Repair malformed handles
	      if(start == null)
		start = il.getStart();
	      if(end == null)
		end = il.getEnd();

	      addLocalVariable(l.getName(), Type.getType(l.getSignature()),
			       l.getSlot(), start, end);
	    }
	  }
	  else
	    System.err.println("Unknown Code attribute " + a + " ignored.");
	}
      }
      else if(a instanceof ExceptionTable) {
	String[] names = ((ExceptionTable)a).getExceptionNames();
	for(int j=0; j < names.length; j++)
	  addException(names[j]);
      }
      else
	addAttribute(a);
    }
  }

  /**
   * Add a local variable to this method.
   *
   * @param name variable name
   * @param type variable type
   * @param slot the index of the local variable, if type is long or double, the next available
   * index is slot+2
   * @param start from where the variable is valid
   * @param end until where the variable is valid
   * @return new local variable object
   * @see LocalVariable
   */
  public LocalVariableGen addLocalVariable(String name, Type type, int slot,
					   InstructionHandle start,
					   InstructionHandle end) {
    byte t   = type.getType();
    int  add = ((t == T_DOUBLE) || (t == T_LONG))? 2 : 1; // double and long take two entries
    
    if(slot + add > max_locals) 
      max_locals = slot + add;

    LocalVariableGen l = new LocalVariableGen(slot, name, type, start, end);
    int i;
    if((i = variable_vec.indexOf(l)) >= 0) // Overwrite if necessary
      variable_vec.setElementAt(l, i);
    else
      variable_vec.addElement(l);
    return l;
  }

  /**
   * Add a local variable to this method and assign an index automatically.
   *
   * @param name variable name
   * @param type variable type
   * @param slot the index of the local variable, if type is long or double, the next available
   * index is slot+2
   * @param start from where the variable is valid, if this is null,
   * it is valid from the start
   * @param end until where the variable is valid, if this is null,
   * it is valid to the end
   * @return new local variable object
   * @see LocalVariable
   */
  public LocalVariableGen addLocalVariable(String name, Type type,
					   InstructionHandle start,
					   InstructionHandle end) {
    return addLocalVariable(name, type, max_locals, start, end);
  }

  /**
   * Remove a local variable, its slot will not be reused, if you do not use addLocalVariable
   * with an explicit `slot' argument.
   */
  public void removeLocalVariable(LocalVariableGen l) {
    variable_vec.removeElement(l);  
  }

  /*
   * If the range of the variable has not been set yet, it will be set to be valid from
   * the start to the end of the instruction list.
   * 
   * @return array of declared local variables
   */
  public final LocalVariableGen[] getLocalVariables() {
    int                size = variable_vec.size();
    LocalVariableGen[] lg   = new LocalVariableGen[size];
    variable_vec.copyInto(lg);
    
    for(int i=0; i < size; i++) {
      if(lg[i].getStart() == null)
	lg[i].setStart(il.getStart());

      if(lg[i].getEnd() == null)
	lg[i].setEnd(il.getEnd());
    }

    return lg;
  }

  /**
   * @return `LocalVariableTable' attribute of all the local variables of this method.
   */
  public final LocalVariableTable getLocalVariableTable(ConstantPoolGen cp) {
    LocalVariableGen[] lg   = getLocalVariables();
    int                size = lg.length;
    LocalVariable[]    lv   = new LocalVariable[size];

    for(int i=0; i < size; i++)
      lv[i] = lg[i].getLocalVariable(cp);

    return new LocalVariableTable(cp.addUtf8("LocalVariableTable"),
				  2 + lv.length * 10, lv, cp.getConstantPool());
  }

  /**
   * Give an instruction a line number corresponding to the source code line.
   *
   * @param ih instruction to tag
   * @return new line number object
   * @see LineNumber
   */
  public LineNumberGen addLineNumber(InstructionHandle ih, int src_line) {
    LineNumberGen l = new LineNumberGen(ih, src_line);
    line_number_vec.addElement(l);
    return l;
  }

  /**
   * Remove a line number.
   */
  public void removeLineNumber(LineNumberGen l) {
    line_number_vec.removeElement(l);  
  }

  /*
   * @return array of line numbers
   */
  public final LineNumberGen[] getLineNumbers() {
    LineNumberGen[] lg   = new LineNumberGen[line_number_vec.size()];
    line_number_vec.copyInto(lg);
    return lg;
  }

  /**
   * @return `LineNumberTable' attribute of all the local variables of this method.
   */
  public final LineNumberTable getLineNumberTable(ConstantPoolGen cp) {
    int          size = line_number_vec.size(); 
    LineNumber[] ln   = new LineNumber[size];

    try {
      for(int i=0; i < size; i++)
	ln[i] = ((LineNumberGen)line_number_vec.elementAt(i)).getLineNumber(cp);
    } catch(ArrayIndexOutOfBoundsException e) {} // Never occurs

    return new LineNumberTable(cp.addUtf8("LineNumberTable"),
			       2 + ln.length * 4, ln, cp.getConstantPool());
  }

  /**
   * Add an exception handler, i.e. specify region where a handler is active and an
   * instruction where the actual handling is done.
   *
   * @param start_pc Start of region
   * @param end_pc End of region
   * @param handler_pc Where handling is done
   * @param catch_type which exception is handled (fully qualified class name)
   * @return new exception handler object
   */
  public CodeExceptionGen addExceptionHandler(InstructionHandle start_pc,
					      InstructionHandle end_pc,
					      InstructionHandle handler_pc,
					      String catch_type) {
    if((start_pc == null) || (end_pc == null) || (handler_pc == null))
      throw new ClassGenException("Exception handler target is a null instruction");
    
    CodeExceptionGen c = new CodeExceptionGen(start_pc, end_pc,
					      handler_pc, catch_type);
    exception_vec.addElement(c);
    return c;
  }

  /**
   * Remove an exception handler.
   */
  public void removeExceptionHandler(CodeExceptionGen c) {
    exception_vec.removeElement(c);  
  }

  /*
   * @return array of declared exception handlers
   */
  public final CodeExceptionGen[] getExceptionHandlers() {
    CodeExceptionGen[] cg   = new CodeExceptionGen[exception_vec.size()];
    exception_vec.copyInto(cg);
    return cg;
  }

  /**
   * @return code exceptions for `Code' attribute
   */
  private final CodeException[] getCodeExceptions() {
    int             size  = exception_vec.size(); 
    CodeException[] c_exc = new CodeException[size];

    try {
      for(int i=0; i < size; i++) {
	CodeExceptionGen c = (CodeExceptionGen)exception_vec.elementAt(i);
	c_exc[i] = c.getCodeException(cp);
      }
    } catch(ArrayIndexOutOfBoundsException e) {}
    
    return c_exc;
  }

  /**
   * Add an exception possibly thrown by this method.
   *
   * @param class_name (fully qualified) name of exception
   */
  public void addException(String class_name) {
    throws_vec.addElement(class_name);
  }

  /**
   * Remove an exception.
   */
  public void removeException(String c) {
    throws_vec.removeElement(c);  
  }

  /*
   * @return array of thrown exceptions
   */
  public final String[] getExceptions() {
    String[] e = new String[throws_vec.size()];
    throws_vec.copyInto(e);
    return e;
  }

  /**
   * @return `Exceptions' attribute of all the exceptions thrown by this method.
   */
  private final ExceptionTable getExceptionTable(ConstantPoolGen cp) {
    int   size = throws_vec.size();
    int[] ex   = new int[size];
      
    try {
      for(int i=0; i < size; i++)
	ex[i] = cp.addClass((String)throws_vec.elementAt(i));
    } catch(ArrayIndexOutOfBoundsException e) {}
    
    return new ExceptionTable(cp.addUtf8("Exceptions"),
			      2 + 2 * size, ex, cp.getConstantPool());
  }

  /**
   * Add an attribute to this method. Currently, the JVM knows about the `Code' and
   * `Exceptions' attribute, which will be generated automatically. Other attributes
   * will be ignored by the JVM but do no harm.
   *
   * @param a attribute to be added
   */
  public void addAttribute(Attribute a) { attribute_vec.addElement(a); }

  /**
   * Remove an attribute.
   */
  public void removeAttribute(Attribute a) { attribute_vec.removeElement(a); }
  
  /**
   * @return all attributes of this method.
   */
  public final Attribute[] getAttributes() {
    Attribute[] attributes = new Attribute[attribute_vec.size()];
    attribute_vec.copyInto(attributes);
    return attributes;
  }

  /**
   * Add an attribute to the code. Currently, the JVM knows about the `LineNumberTable' and
   * `LocalVariableTable' attributes, which will be generated automatically. Other attributes
   * will be ignored by the JVM but do no harm.
   *
   * @param a attribute to be added
   */
  public void addCodeAttribute(Attribute a) { code_attrs_vec.addElement(a); }

  /**
   * Remove a code attribute.
   */
  public void removeCodeAttribute(Attribute a) { code_attrs_vec.removeElement(a);  
  }
  
  /**
   * @return all attributes of this method.
   */
  public final Attribute[] getCodeAttributes() {
    Attribute[] attributes = new Attribute[ code_attrs_vec.size()];
    code_attrs_vec.copyInto(attributes);
    return attributes;
  }

  /**
   * Get method object.
   *
   * The maximum stack size has to be supplied by the user, since it is hard
   * to determine statically with just the byte code at hands. I.e. you'd have to
   * identify loops and such. The stack size can be computed much easier on the fly 
   * when creating the code.
   *
   * @param max_stack maximum stack size of this method
   * @return method object
   * @deprecated
   */
  public final Method getMethod(int max_stack) {
    setMaxStack(max_stack);
    return getMethod();
  }

  /**
   * Get method object.
   *
   * The maximum stack size has to be supplied by the user, since it is hard
   * to determine statically with just the byte code at hands. I.e. you'd have to
   * identify loops and such. The stack size can be computed much easier on the fly 
   * when creating the code.
   * So never forget to call setMaxStack() before calling this method.
   *
   * @return method object
   */
  public Method getMethod() {
    String signature       = Type.getMethodSignature(return_type, arg_types);
    int    name_index      = cp.addUtf8(method_name);
    int    signature_index = cp.addUtf8(signature);

    /* Also updates positions of instructions, i.e. their indices
     */
    byte[] byte_code = null;

    if(il != null)
      byte_code = il.getByteCode();

    /* Create LocalVariableTable and LineNumberTable attributes (for debuggers, e.g.)
     */
    if(variable_vec.size() > 0)
      addCodeAttribute(getLocalVariableTable(cp));

    if(line_number_vec.size() > 0)
      addCodeAttribute(getLineNumberTable(cp));

    Attribute[] code_attrs = getCodeAttributes();

    /* Each attribute causes 6 additional header bytes
     */
    int                attrs_len  = 0;
    for(int i=0; i < code_attrs.length; i++)
      attrs_len += (code_attrs[i].getLength() + 6);

    CodeException[] c_exc   = getCodeExceptions();
    int             exc_len = c_exc.length * 8; // Every entry takes 8 bytes

    if(il != null) {
      Code code = new Code(cp.addUtf8("Code"),
			   8 + byte_code.length + // prologue byte code
			   2 + exc_len +          // exceptions
			   2 + attrs_len,         // attributes
			   max_stack, max_locals,
			   byte_code, c_exc,
			   code_attrs,
			   cp.getConstantPool());

      addAttribute(code);
    }
    
    if(throws_vec.size() > 0)
      addAttribute(getExceptionTable(cp)); // Add `Exceptions' if there are "throws" clauses

    return new Method(access_flags, name_index, signature_index,
		      getAttributes(), cp.getConstantPool());
  }

  /**
   * Checks an instruction handle whether it contains a NOP instruction. If so,
   * update the instruction and add the NOP instruction to a given vector, if
   * it is not already in there.
   *
   * @param nop_vec Vector containing NOP instruction handles
   * @param target Target instruction handle being referenced
   */
  private static final InstructionHandle checkTarget(/* VAR */ Vector nop_vec,
						     InstructionHandle target) {
    InstructionHandle new_target = target;
    
    if(target.instruction instanceof NOP) { // Redundant. Remove it later,
      if(!nop_vec.contains(target))         // because it may be the
	nop_vec.addElement(target); 	    // target of multiple instructions
      
      for(new_target = target;         // Search for non-NOP or very last NOP in il
	  (new_target.next != null) && 
	  (new_target.instruction instanceof NOP); // instruction 
	  new_target = new_target.next);

      // if(new_target == null) // at end of list: can't be correct code
      // 	return target;
      // 	throw new ClassGenException("Instruction list ends with NOP.");
    }

    return new_target;
  }

  /**
   * Remove all NOPs from the instruction list (if possible) and update every
   * object refering to them, i.e. branch instructions, local variables and
   * exception handlers.
   */
  public final void removeNOPs() {
    Vector nop_vec = new Vector();

    /* Check branch instructions.
     */
    for(InstructionHandle ih = il.getStart(); ih != null; ih = ih.next) {
      Instruction       i  = ih.getInstruction();

      if(i instanceof BranchInstruction) {
	BranchInstruction b      = (BranchInstruction)i;
	InstructionHandle target = b.getTarget();

	b.setTarget(checkTarget(nop_vec, target));

	if(b instanceof Select) { // Either LOOKUPSWITCH or TABLESWITCH
	  InstructionHandle[] targets = ((Select)b).getTargets();
	  
	  for(int j=0; j < targets.length; j++) // Update targets
	    targets[j] = checkTarget(nop_vec, targets[j]);
	}
      }
    }
    
    /* Check the scope of all local variables.
     */
    LocalVariableGen[] lg = getLocalVariables();

    for(int i=0; i < lg.length; i++) {
      InstructionHandle start = lg[i].getStart();
      InstructionHandle end   = lg[i].getEnd();
      
      if(start != null)
	lg[i].setStart(checkTarget(nop_vec, start));

      if(end != null)
	lg[i].setEnd(checkTarget(nop_vec, end));
    }

    /* Check all declared exception handlers.
     */
    CodeExceptionGen[] exceptions = getExceptionHandlers();

    for(int i=0; i < exceptions.length; i++) {
      exceptions[i].setStartPC(checkTarget(nop_vec, exceptions[i].getStartPC()));
      exceptions[i].setEndPC(checkTarget(nop_vec, exceptions[i].getEndPC()));
      exceptions[i].setHandlerPC(checkTarget(nop_vec, exceptions[i].getHandlerPC()));
    }

    /* Check for any remaining NOPs not targetted anywhere in the code, except
     * for the very last one. This one may be necessary in some cases as a dummy target
     * that will in fact never be used, but is needed for the byte code verifier.
     */
    for(InstructionHandle ih = il.getStart(); ih != null; ih = ih.next)
      if((ih.getInstruction() instanceof NOP) && !nop_vec.contains(ih) && (ih.next != null))
	nop_vec.addElement(ih);

    /* Finally remove all redundant NOPs from the list, all instructions, etc.
     * targetting them, have been updated.
     */
    int size = nop_vec.size();

    try {
      for(int i=0; i < size; i++) {
	InstructionHandle ih = (InstructionHandle)nop_vec.elementAt(i);
	il.delete(ih);
      }
    } catch(ArrayIndexOutOfBoundsException e) {
      System.out.println("Never occurs: " + e);
    }
  }

  /**
   * Set maximum stack size for this method.
   */
  public void   setMaxLocals(int m)  { max_locals = m; }

  /**
   * Set maximum number of local variables.
   */
  public void   setMaxStack(int m)  { max_stack = m; }

  public int    getMaxLocals() { return max_locals; }
  public int    getMaxStack()  { return max_stack; }

  public void   setMethodName(String method_name)  { this.method_name = method_name; }
  public String getMethodName()                    { return method_name; }
  public String getClassName()                     { return class_name; }
  public void   setReturnType(Type return_type)    { this.return_type = return_type; }
  public Type   getReturnType()                    { return return_type; }
  public void   setArgTypes(Type[] arg_types)      { this.arg_types = arg_types; }
  public Type[] getArgTypes()                      { return arg_types; }
  public void   setAccessFlags(short access_flags) { this.access_flags = access_flags;}
  public int    getAccessFlags()                   { return access_flags; }

  public InstructionList getInstructionList()      { return il; }
  public ConstantPoolGen getConstantPool()         { return cp; }

  public String getMethodSignature() { 
    return Type.getMethodSignature(return_type, arg_types);
  }
}
