package DE.fub.inf.JVM.ClassGen;
import java.io.*;

/** 
 * SWITCH - Branch depending on int value, generates either LOOKUPSWITCH or
 * TABLESWITCH instruction, depending on whether the match values (int[]) can be
 * sorted with no gaps between the numbers.
 *
 * @version $Id: SWITCH.java,v 1.1 1998/07/01 13:08:06 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public final class SWITCH implements CompoundInstruction {
  private int[]               match;
  private InstructionHandle[] targets;
  private Select              instruction;
  private int                 match_length;

  /**
   * Template for switch() constructs, if the match array can be sorted
   * in ascending order with no gaps between the numbers a TABLESWITCH
   * instruction is generated, a LOOKUPSWITCH otherwise.
   *
   * @param match array of match values (case 2: ... case 7: ..., etc.)
   * @param targets the instructions to be performed for each case
   * @param target the default target
   */
  public SWITCH(int[] match, InstructionHandle[] targets,
		InstructionHandle target) {
    this.match   = match;
    match_length = match.length;
    sort(0, match_length - 1);

    if(matchIsOrdered())
      instruction = new TABLESWITCH(match, targets, target);
    else
      instruction = new LOOKUPSWITCH(match, targets, target);
  }


  /**
   * Sort match and targets array with QuickSort.
   */
  private final void sort(int l, int r) {
    int i = l, j = r;
    int h, m = match[(l + r) / 2];
    InstructionHandle h2;

    while(true) {
      while(match[i] < m) i++;
      while(m < match[j]) j--;

      if(i <= j) {
	h=match[i]; match[i]=match[j]; match[j]=h; // Swap elements
	h2=targets[i]; targets[i]=targets[j]; targets[j]=h2; // Swap instructions, too
	i++; j--;
      }
      else
	break;
    }

    if(l < j) sort(l, j);
    if(i < r) sort(i, r);
  }

  /**
   * @return match is sorted in ascending order?
   */
  private final boolean matchIsOrdered() {
    for(int i=1; i < match_length; i++)
      if(match[i] != match[i-1] + 1)
	return false;

    return true;
  }

  public final InstructionList getInstructionList() {
    return new InstructionList(instruction);
  }

  public final Instruction getInstruction() {
    return instruction;
  }
}
