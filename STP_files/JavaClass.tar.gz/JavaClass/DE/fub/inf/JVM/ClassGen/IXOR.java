package DE.fub.inf.JVM.ClassGen;

/** 
 * IXOR - Bitwise XOR int
 * Stack: ..., value1, value2 -> ..., result
 *
 * @version $Id: IXOR.java,v 1.1 1998/07/01 13:07:15 dahm Exp $
 * @authXOR  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class IXOR extends Instruction {
  public IXOR() {
    super(IXOR, (short)1);
  }
}

