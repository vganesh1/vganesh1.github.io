package DE.fub.inf.JVM.ClassGen;

/**
 * Denotes an instruction to perform an unconditional branch, i.e. GOTO, JSR.
 *
 * @version $Id: UnconditionalBranch.java,v 1.2 1998/10/16 09:32:25 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>

 * @see GOTO
 * @see JSR
 */
public interface UnconditionalBranch {}

