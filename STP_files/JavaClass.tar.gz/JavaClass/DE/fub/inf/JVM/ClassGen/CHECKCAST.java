package DE.fub.inf.JVM.ClassGen;

/** 
 * CHECKCAST - Check whether object is of given type
 * Stack: ..., objectref -> ..., objectref
 *
 * @version $Id: CHECKCAST.java,v 1.2 1998/07/29 19:50:33 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class CHECKCAST extends CPInstruction implements LoadClass {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  CHECKCAST() {}

  public CHECKCAST(int index) {
    super(CHECKCAST, index);
  }
}

