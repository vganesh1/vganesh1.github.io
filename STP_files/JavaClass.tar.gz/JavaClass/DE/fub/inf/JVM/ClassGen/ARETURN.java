package DE.fub.inf.JVM.ClassGen;

/** 
 * ARETURN -  Return reference from method
 * Stack: ..., objectref -> <empty>
 *
 * @version $Id: ARETURN.java,v 1.2 1998/08/05 15:13:16 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class ARETURN extends ReturnInstruction {
  public ARETURN() {
    super(ARETURN, 1);
  }
}

