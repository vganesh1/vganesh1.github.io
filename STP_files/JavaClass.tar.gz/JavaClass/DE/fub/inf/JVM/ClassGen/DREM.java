package DE.fub.inf.JVM.ClassGen;

/** 
 * DREM - Remainder of doubles
 * Stack: ..., value1.word1, value1.word2, value2.word1, value2.word2 ->
 *        ..., result.word1, result.word2
 *
 * @version $Id: DREM.java,v 1.1 1998/07/01 13:05:55 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class DREM extends Instruction {
  public DREM() {
    super(DREM, (short)1);
  }
}

