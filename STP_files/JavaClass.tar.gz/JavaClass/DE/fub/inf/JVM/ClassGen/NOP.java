package DE.fub.inf.JVM.ClassGen;

/**
 * NOP - Do nothing
 *
 * @version $Id: NOP.java,v 1.1 1998/07/01 13:07:54 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class NOP extends Instruction {
  public NOP() {
    super(NOP, (short)1);
  }
}

