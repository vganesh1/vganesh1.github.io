package DE.fub.inf.JVM.ClassGen;
import DE.fub.inf.JVM.Constants;
import DE.fub.inf.JVM.JavaClass.ConstantPool;

/**
 * Super class for the GET/PUTxxx family of instructions.
 *
 * @version $Id: FieldInstruction.java,v 1.2 1998/08/14 16:56:11 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public abstract class FieldInstruction extends CPInstruction implements LoadClass, Constants {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  FieldInstruction() {}

  /**
   * @param index to constant pool
   */
  protected FieldInstruction(short tag, int index) {
    super(tag, index);
  }

  /**
   * @return mnemonic for instruction with sumbolic references resolved
   */
  public String toString(ConstantPool cp) {
    return OPCODE_NAMES[tag] + " " + cp.constantToString(index, CONSTANT_Fieldref);
  }
}
