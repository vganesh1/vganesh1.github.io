package DE.fub.inf.JVM.ClassGen;

/** 
 * LNEG - Negate long
 * Stack: ..., value.word1, value.word2 -> ..., result.word1, result.word2
 *
 * @version $Id: LNEG.java,v 1.1 1998/07/01 13:07:36 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class LNEG extends Instruction {
  public LNEG() {
    super(LNEG, (short)1);
  }
}

