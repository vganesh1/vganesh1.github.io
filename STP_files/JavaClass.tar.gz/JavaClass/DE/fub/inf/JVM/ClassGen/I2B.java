package DE.fub.inf.JVM.ClassGen;

/** 
 * I2B - Convert int to byte
 * Stack: ..., value -> ..., result
 *
 * @version $Id: I2B.java,v 1.1 1998/07/01 13:06:27 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class I2B extends Instruction {
  public I2B() {
    super(I2B, (short)1);
  }
}

