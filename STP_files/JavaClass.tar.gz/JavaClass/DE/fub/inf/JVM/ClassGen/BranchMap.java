package DE.fub.inf.JVM.ClassGen;
import java.util.Hashtable;
import java.util.Vector;

/**
 * Map instruction handles to branch handles that are targetting it.
 *
 * @version $Id: BranchMap.java,v 1.1 1998/10/22 14:06:01 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 * @see     InstructionList
 * @see     InstructionHandle
 * @see     BranchHandle
 */
public class BranchMap {
  Hashtable map = new Hashtable();

  public BranchMap(InstructionList il) {
    for(InstructionHandle ih = il.getStart(); ih != null; ih = ih.getNext()) {
      if(ih instanceof BranchHandle)
	put((BranchHandle)ih);
    }
  }

  private final Vector getVector(InstructionHandle ih, boolean create) {
    Vector vec = (Vector)map.get(ih);

    if((vec == null) && create) {
      vec = new Vector();
      map.put(ih, vec);
    }
    
    return vec;
  }

  /**
   * @param ih instruction being targetted by
   * @param bh branch instruction
   */
  private void put(BranchHandle bh) {
    BranchInstruction bi  = (BranchInstruction)bh.getInstruction();
    InstructionHandle ih  = bi.getTarget();
    Vector            vec = getVector(ih, true);

    vec.addElement(bh);

    if(bi instanceof Select) { // Either LOOKUPSWITCH or TABLESWITCH
      InstructionHandle[] targets = ((Select)bi).getTargets();
      
      for(int i=0; i < targets.length; i++) { // Update all targets
	vec = getVector(targets[i], true);
	vec.addElement(bh);
      }
    }
  }

  private static final BranchHandle[] empty = new BranchHandle[0];

  /**
   * @return all branch handles targetting this instruction
   */
  public BranchHandle[] getTargetters(InstructionHandle ih) {
    Vector vec = getVector(ih, false);

    if(vec == null)
      return empty;

    BranchHandle[] handles = new BranchHandle[vec.size()];
    vec.copyInto(handles);
    return handles;
  }
}
