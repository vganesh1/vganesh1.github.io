package DE.fub.inf.JVM.ClassGen;

/** 
 * DNEG - Negate double
 * Stack: ..., value.word1, value.word2 -> ..., result.word1, result.word2
 *
 * @version $Id: DNEG.java,v 1.1 1998/07/01 13:05:54 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class DNEG extends Instruction {
  public DNEG() {
    super(DNEG, (short)1);
  }
}

