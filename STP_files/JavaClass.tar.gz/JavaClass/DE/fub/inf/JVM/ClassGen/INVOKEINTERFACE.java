package DE.fub.inf.JVM.ClassGen;
import DE.fub.inf.JVM.JavaClass.ConstantPool;

import java.io.*;
import DE.fub.inf.JVM.Util.ByteSequence;

/** 
 * INVOKEINTERFACE - Invoke interface method
 * Stack: ..., objectref, [arg1, [arg2 ...]] -> ...
 *
 * @version $Id: INVOKEINTERFACE.java,v 1.3 1998/08/14 16:56:13 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public final class INVOKEINTERFACE extends InvokeInstruction {
  private int nargs; // Number of arguments on stack

  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  INVOKEINTERFACE() {}

  public INVOKEINTERFACE(int index, int nargs) {
    super(INVOKEINTERFACE, index);
    length = 5;

    if(nargs < 1)
      throw new ClassGenException("Number of arguments must be > 0 " + nargs);

    this.nargs = nargs;
  }

  /**
   * Dump instruction as byte code to stream out.
   * @param out Output stream
   */
  public void dump(DataOutputStream out) throws IOException {
    out.writeByte(tag);
    out.writeShort(index);
    out.writeByte(nargs);
    out.writeByte(0);
  }

  public int getNoArguments() { return nargs; }

  /**
   * Read needed data (i.e. index) from file.
   */
  protected void initFromFile(ByteSequence bytes, boolean wide)
       throws IOException
  {
    super.initFromFile(bytes, wide);

    length = 5;
    nargs = bytes.readUnsignedByte();
    bytes.readByte(); // Skip 0 byte
  }

  /**
   * @return mnemonic for instruction with sumbolic references resolved
   */
  public String toString(ConstantPool cp) {
    return super.toString(cp) + " " + nargs;
  }
}
