package DE.fub.inf.JVM.ClassGen;

/** 
 * DADD - Add doubles
 * Stack: ..., value1.word1, value1.word2, value2.word1, value2.word2 -> 
 *        ..., result.word1, result1.word2
 *
 * @version $Id: DADD.java,v 1.1 1998/07/01 13:05:46 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class DADD extends Instruction {
  public DADD() {
    super(DADD, (short)1);
  }
}

