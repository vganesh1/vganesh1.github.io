package DE.fub.inf.JVM.ClassGen;

/** 
 * INVOKEVIRTUAL - Invoke instance method; dispatch based on class
 *
 * Stack: ..., objectref, [arg1, [arg2 ...]] -> ...
 *
 * @version $Id: INVOKEVIRTUAL.java,v 1.2 1998/07/29 19:50:40 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class INVOKEVIRTUAL extends InvokeInstruction {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  INVOKEVIRTUAL() {}

  public INVOKEVIRTUAL(int index) {
    super(INVOKEVIRTUAL, index);
  }
}

