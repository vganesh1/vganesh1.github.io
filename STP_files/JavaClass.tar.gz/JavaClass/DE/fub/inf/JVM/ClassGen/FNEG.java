package DE.fub.inf.JVM.ClassGen;

/** 
 * FNEG - Negate float
 * Stack: ..., value -> ..., result
 *
 * @version $Id: FNEG.java,v 1.1 1998/07/01 13:06:17 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class FNEG extends Instruction {
  public FNEG() {
    super(FNEG, (short)1);
  }
}

