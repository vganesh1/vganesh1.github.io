package DE.fub.inf.JVM.ClassGen;

/** 
 * I2C - Convert int to char
 * Stack: ..., value -> ..., result
 *
 * @version $Id: I2C.java,v 1.1 1998/07/01 13:06:28 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class I2C extends Instruction {
  public I2C() {
    super(I2C, (short)1);
  }
}

