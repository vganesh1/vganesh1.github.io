package DE.fub.inf.JVM.ClassGen;

/** 
 * LALOAD - Load long from array
 * Stack: ..., arrayref, index -> ..., value1, value2
 *
 * @version $Id: LALOAD.java,v 1.1 1998/07/01 13:07:25 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class LALOAD extends Instruction {
  public LALOAD() {
    super(LALOAD, (short)1);
  }
}

