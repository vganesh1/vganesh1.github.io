package DE.fub.inf.JVM.ClassGen;

/** 
 * ANEWARRAY -  Create new array of references
 * Stack: ..., count -> ..., arrayref
 *
 * @version $Id: ANEWARRAY.java,v 1.2 1998/07/29 19:50:31 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class ANEWARRAY extends CPInstruction implements LoadClass {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  ANEWARRAY() {}

  public ANEWARRAY(int index) {
    super(ANEWARRAY, index);
  }
}

