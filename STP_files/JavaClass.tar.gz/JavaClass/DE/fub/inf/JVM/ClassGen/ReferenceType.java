package DE.fub.inf.JVM.ClassGen;

/** 
 * Super class for objects and arrays.
 *
 * @version $Id: ReferenceType.java,v 1.2 1998/10/22 14:06:17 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class ReferenceType extends Type {
  protected ReferenceType(byte t, String s) {
    super(t, s);
  }

  private ReferenceType() { super((byte)0, "null"); }
  private static final ReferenceType n = new ReferenceType();
  static final ReferenceType getNull() { return n; }
}
