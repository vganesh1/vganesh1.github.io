package DE.fub.inf.JVM.ClassGen;

/** 
 * IMUL - Multiply ints
 * Stack: ..., value1, value2 -> result
 *
 * @version $Id: IMUL.java,v 1.1 1998/07/01 13:07:00 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class IMUL extends Instruction {
  public IMUL() {
    super(IMUL, (short)1);
  }
}

