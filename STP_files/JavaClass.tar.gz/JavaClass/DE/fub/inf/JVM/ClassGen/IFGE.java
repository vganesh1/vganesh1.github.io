package DE.fub.inf.JVM.ClassGen;

/** 
 * IFGE - Branch if int comparison with zero succeeds
 *
 * Stack: ..., value -> ...
 *
 * @version $Id: IFGE.java,v 1.3 1998/10/22 14:06:05 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class IFGE extends IfInstruction {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  IFGE() {}

  public IFGE(InstructionHandle target) {
    super(IFGE, target);
  }

  /**
   * @return negation of instruction
   */
  public IfInstruction negate() {
    return new IFLT(target);
  }
}
