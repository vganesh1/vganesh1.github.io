package DE.fub.inf.JVM.ClassGen;

/** 
 * PUTSTATIC - Put static field in class
 * Stack: ..., objectref, value -> ...
 * OR
 * Stack: ..., objectref, value.word1, value.word2 -> ...
 *
 * @version $Id: PUTSTATIC.java,v 1.2 1998/07/29 19:50:48 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class PUTSTATIC extends FieldInstruction {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  PUTSTATIC() {}

  public PUTSTATIC(int index) {
    super(PUTSTATIC, index);
  }
}

