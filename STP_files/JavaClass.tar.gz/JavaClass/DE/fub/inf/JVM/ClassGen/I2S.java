package DE.fub.inf.JVM.ClassGen;

/**
 * I2S - Convert int to short
 * Stack: ..., value -> ..., result
 *
 * @version $Id: I2S.java,v 1.1 1998/07/01 13:06:33 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class I2S extends Instruction {
  public I2S() {
    super(I2S, (short)1);
  }
}

