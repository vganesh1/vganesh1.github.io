package DE.fub.inf.JVM.ClassGen;
import java.io.*;
import DE.fub.inf.JVM.Util.ByteSequence;
import DE.fub.inf.JVM.JavaClass.Utility;

/** 
 * Abstract super class for instructions dealing with local variables.
 *
 * @version $Id: LocalVariableInstruction.java,v 1.4 1998/09/15 08:42:25 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public abstract class LocalVariableInstruction extends Instruction {
  private int     n;     // index of referenced variable
  private boolean wide;  // wide prefix needed for this instruction
  private short   c_tag; // compact version, such as ALOAD_0

  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  LocalVariableInstruction() {}

  /**
   * @param tag Instruction number
   * @param c_tag Instruction number for compact version, ALOAD_0, e.g.
   * @param n local variable index (unsigned short)
   */
  protected LocalVariableInstruction(short tag, short c_tag, int n) {
    super(tag, (short)2);

    this.c_tag = c_tag;

    setIndex(n);
  }

  /**
   * Dump instruction as byte code to stream out.
   * @param out Output stream
   */
  public void dump(DataOutputStream out) throws IOException {
    if(wide) // Need WIDE prefix ?
      out.writeByte(WIDE);

    out.writeByte(tag);

    if(length > 1) { // Otherwise ILOAD_n, instruction, e.g.
      if(wide)
	out.writeShort(n);
      else
	out.writeByte(n);
    }
  }

  /**
   * Long output format:
   *
   * &lt;position in byte code&gt;
   * &lt;name of opcode&gt; "["&lt;opcode number&gt;"]" 
   * "("&lt;length of instruction&gt;")" "&lt;"&lt; local variable index&gt;"&gt;"
   *
   * @param verbose long/short format switch
   * @return mnemonic for instruction
   */
  public String toString(boolean verbose) {
    String str;

    if(((tag >= ILOAD_0) && (tag <= ALOAD_3)) ||
       ((tag >= ISTORE_0) && (tag <= ASTORE_3)))
      str = OPCODE_NAMES[tag];
    else
      str = OPCODE_NAMES[tag] + " " + n;

    if(verbose)
      return Utility.format(position, 4, false, ' ') + ": "  + str;
    else
      return str;
  }

  /**
   * Read needed data (e.g. index) from file.
   * PRE: (ILOAD <= tag <= ALOAD_3) || (ISTORE <= tag <= ASTORE_3)
   */
  protected void initFromFile(ByteSequence bytes, boolean wide)
    throws IOException
  {
    if(wide) {
      n         = bytes.readUnsignedShort();
      this.wide = true;
      length    = 4;
    }
    else if(((tag >= ILOAD)  && (tag <= ALOAD)) ||
	    ((tag >= ISTORE) && (tag <= ASTORE))) {
      n      = bytes.readUnsignedByte();
      length = 2;
    }
    else if(tag <= ALOAD_3) { // compact load instruction such as ILOAD_2
      n      = (tag - ILOAD_0) % 4;
      length = 1;
    }
    else { // Assert ISTORE_0 <= tag <= ASTORE_3
      n      = (tag - ISTORE_0) % 4;
      length = 1;
    }
 }

  /**
   * @return local variable index  referred by this instruction.
   */
  public final int getIndex() { return n; }

  /**
   * Set the local variable index
   */
  public final void setIndex(int n) { 
    if((n < 0) || (n > MAX_SHORT))
      throw new ClassGenException("Illegal value: " + n);

    if(n >= 0 && n <= 3) { // Use more compact instruction xLOAD_n
      this.tag = (short)(c_tag + n);
      length   = 1;
    }
      
    if(wide = n > MAX_BYTE) // Need WIDE prefix ?
      length = 4;

    this.n = n;
  }
}
