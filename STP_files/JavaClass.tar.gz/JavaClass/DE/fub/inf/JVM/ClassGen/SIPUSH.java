package DE.fub.inf.JVM.ClassGen;
import java.io.*;
import DE.fub.inf.JVM.Util.ByteSequence;

/**
 * SIPUSH - Push short
 *
 * Stack: ... -> ..., value
 *
 * @version $Id: SIPUSH.java,v 1.4 1998/10/16 09:54:08 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class SIPUSH extends Instruction implements ConstantPushInstruction {
  private short b;

  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  SIPUSH() {}

  public SIPUSH(short b) {
    super(SIPUSH, (short)3);
    this.b = b;
  }

  /**
   * Dump instruction as short code to stream out.
   */
  public void dump(DataOutputStream out) throws IOException {
    super.dump(out);
    out.writeShort(b);
  }

  /**
   * @return mnemonic for instruction
   */
  public String toString(boolean verbose) {
    return super.toString(verbose) + " " + b;
  }

  /**
   * Read needed data (e.g. index) from file.
   */
  protected void initFromFile(ByteSequence bytes, boolean wide) throws IOException
  {
    length = 3;
    b      = bytes.readShort();
  }

  public Number getValue() { return new Integer(b); }
}

