package DE.fub.inf.JVM.ClassGen;

/** 
 * FCMPG - Compare floats: value1 > value2
 * Stack: ..., value1, value2 -> ..., result
 *
 * @version $Id: FCMPG.java,v 1.1 1998/07/01 13:06:11 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class FCMPG extends Instruction {
  public FCMPG() {
    super(FCMPG, (short)1);
  }
}

