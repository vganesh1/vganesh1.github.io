package DE.fub.inf.JVM.ClassGen;

/** 
 * BASTORE -  Store into byte or boolean array
 * Stack: ..., arrayref, index, value -> ...
 *
 * @version $Id: BASTORE.java,v 1.1 1998/07/01 13:05:29 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class BASTORE extends Instruction {
  public BASTORE() {
    super(BASTORE, (short)1);
  }
}

