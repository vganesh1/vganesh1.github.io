package DE.fub.inf.JVM.ClassGen;

/** 
 * ILOAD - Load int from local variable
 * Stack ... -> ..., result
 *
 * @version $Id: ILOAD.java,v 1.2 1998/10/16 09:32:18 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class ILOAD extends LocalVariableInstruction implements PushInstruction {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  ILOAD() {}

  public ILOAD(int n) {
    super(ILOAD, ILOAD_0, n);
  }
}

