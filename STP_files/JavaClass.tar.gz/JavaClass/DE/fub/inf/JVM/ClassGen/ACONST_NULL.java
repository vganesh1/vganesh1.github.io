package DE.fub.inf.JVM.ClassGen;

/** 
 * ACONST_NULL -  Push null
 * Stack: ... -> ..., null
 *
 * @version $Id: ACONST_NULL.java,v 1.2 1998/10/16 09:32:09 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class ACONST_NULL extends Instruction implements PushInstruction {
  public ACONST_NULL() {
    super(ACONST_NULL, (short)1);
  }
}

