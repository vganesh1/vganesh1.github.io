package DE.fub.inf.JVM.ClassGen;

/** 
 * LDC2_W - Push long or double from constant pool
 *
 * Stack: ... -> ..., item.word1, item.word2
 *
 * @version $Id: LDC2_W.java,v 1.2 1998/10/16 09:32:20 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class LDC2_W extends CPInstruction implements PushInstruction {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  LDC2_W() {}

  public LDC2_W(int index) {
    super(LDC2_W, index);
  }
}

