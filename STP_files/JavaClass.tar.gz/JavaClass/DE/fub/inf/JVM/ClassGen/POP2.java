package DE.fub.inf.JVM.ClassGen;

/**
 * POP2 - Pop two top operand stack words
 *
 * Stack: ..., word2, word1 -> ...
 *
 * @version $Id: POP2.java,v 1.2 1998/10/16 09:32:22 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class POP2 extends PopInstruction {
  public POP2() {
    super(POP2, (short)1);
  }
}

