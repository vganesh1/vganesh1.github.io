package DE.fub.inf.JVM.ClassGen;

/** 
 * CALOAD - Load char from array
 * Stack: ..., arrayref, index -> ..., value
 *
 * @version $Id: CALOAD.java,v 1.1 1998/07/01 13:05:34 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class CALOAD extends Instruction {
  public CALOAD() {
    super(CALOAD, (short)1);
  }
}

