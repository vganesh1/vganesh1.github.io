package DE.fub.inf.JVM.ClassGen;

/** 
 * ARRAYLENGTH -  Get length of array
 * Stack: ..., arrayref -> ..., length
 *
 * @version $Id: ARRAYLENGTH.java,v 1.1 1998/07/01 13:05:25 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class ARRAYLENGTH extends Instruction {
  public ARRAYLENGTH() {
    super(ARRAYLENGTH, (short)1);
  }
}

