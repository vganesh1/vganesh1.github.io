package DE.fub.inf.JVM.ClassGen;

/** 
 * IF_ICMPGE - Branch if int comparison succeeds
 *
 * Stack: ..., value1, value2 -> ...
 *
 * @version $Id: IF_ICMPGE.java,v 1.3 1998/10/22 14:06:11 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class IF_ICMPGE extends IfInstruction {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  IF_ICMPGE() {}

  public IF_ICMPGE(InstructionHandle target) {
    super(IF_ICMPGE, target);
  }

  /**
   * @return negation of instruction
   */
  public IfInstruction negate() {
    return new IF_ICMPLT(target);
  }
}

