package DE.fub.inf.JVM.ClassGen;

/** 
 * IRETURN -  Return int from method
 * Stack: ..., value -> <empty>
 *
 * @version $Id: IRETURN.java,v 1.2 1998/08/05 15:13:21 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class IRETURN extends ReturnInstruction {
  public IRETURN() {
    super(IRETURN, 1);
  }
}

