package DE.fub.inf.JVM.ClassGen;

/**
 * I2L - Convert int to long
 * Stack: ..., value -> ..., result.word1, result.word2
 *
 * @version $Id: I2L.java,v 1.1 1998/07/01 13:06:31 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class I2L extends Instruction {
  public I2L() {
    super(I2L, (short)1);
  }
}

