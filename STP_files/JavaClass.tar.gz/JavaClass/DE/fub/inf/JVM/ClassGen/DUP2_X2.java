package DE.fub.inf.JVM.ClassGen;

/** 
 * DUP2_X2 - Duplicate two top operand stack words and put four down
 * Stack: ..., word4, word3, word2, word1 -> ..., word2, word1, word4, word3, word2, word1
 *
 * @version $Id: DUP2_X2.java,v 1.1 1998/07/01 13:06:02 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class DUP2_X2 extends Instruction {
  public DUP2_X2() {
    super(DUP2_X2, (short)1);
  }
}

