package DE.fub.inf.JVM.ClassGen;

/** 
 * I2F - Convert int to float
 * Stack: ..., value -> ..., result
 *
 * @version $Id: I2F.java,v 1.1 1998/07/01 13:06:30 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class I2F extends Instruction {
  public I2F() {
    super(I2F, (short)1);
  }
}

