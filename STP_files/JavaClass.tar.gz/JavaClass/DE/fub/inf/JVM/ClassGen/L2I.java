package DE.fub.inf.JVM.ClassGen;

/**
 * L2I - Convert long to int
 * Stack: ..., value.word1, value.word2 -> ..., result
 *
 * @version $Id: L2I.java,v 1.1 1998/07/01 13:07:23 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class L2I extends Instruction {
  public L2I() {
    super(L2I, (short)1);
  }
}

