package DE.fub.inf.JVM.ClassGen;

/** 
 * INVOKESTATIC - Invoke a class (static) method
 *
 * Stack: ..., [arg1, [arg2 ...]] -> ...
 *
 * @version $Id: INVOKESTATIC.java,v 1.2 1998/07/29 19:50:39 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class INVOKESTATIC extends InvokeInstruction {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  INVOKESTATIC() {}

  public INVOKESTATIC(int index) {
    super(INVOKESTATIC, index);
  }
}

