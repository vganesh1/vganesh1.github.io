package DE.fub.inf.JVM.ClassGen;

/** 
 * LUSHR - Logical shift right long
 * Stack: ..., value1, value2 -> ..., result
 *
 * @version $Id: LUSHR.java,v 1.1 1998/07/01 13:07:45 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class LUSHR extends Instruction {
  public LUSHR() {
    super(LUSHR, (short)1);
  }
}

