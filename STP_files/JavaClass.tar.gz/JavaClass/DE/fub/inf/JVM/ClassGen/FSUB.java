package DE.fub.inf.JVM.ClassGen;

/**
 * FSUB - Substract floats
 * Stack: ..., value1, value2 -> result
 *
 * @version $Id: FSUB.java,v 1.1 1998/07/01 13:06:21 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class FSUB extends Instruction {
  public FSUB() {
    super(FSUB, (short)1);
  }
}

