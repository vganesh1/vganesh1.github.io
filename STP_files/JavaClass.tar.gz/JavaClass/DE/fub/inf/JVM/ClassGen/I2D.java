package DE.fub.inf.JVM.ClassGen;

/**
 * I2D - Convert int to double
 * Stack: ..., value -> ..., result.word1, result.word2
 *
 * @version $Id: I2D.java,v 1.1 1998/07/01 13:06:29 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class I2D extends Instruction {
  public I2D() {
    super(I2D, (short)1);
  }
}

