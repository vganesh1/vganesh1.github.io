#include "c_interface.h"
#include <stdio.h>

int main () {
  int r;
  VC vc = vc_createValidityChecker();
  //  vc_setFlags ('n');
  vc_setFlags ('d');
  vc_setFlags ('p');

  // 32-bit variable
  Expr i = vc_varExpr1(vc, "i", 0, 32);

  // 32-bit constant, value is 7.
  Expr c7 = vc_bvConstExprFromInt(vc, 32, 7);

  // assert that both (i < 7) AND (i > 7) are true.
  Expr ilt7 = vc_bvLtExpr (vc, i, c7);
  Expr igt7 = vc_bvGtExpr (vc, i, c7);
  vc_assertFormula (vc, ilt7);
  vc_assertFormula (vc, igt7);

  // check if constraint set is satisifable.
  Expr falsee = vc_falseExpr(vc);
  r = vc_query (vc, falsee);
  if (r == 0)
    printf ("cs is satisfiable\n");
  else
    printf ("cs is not satisfiable\n");

  vc_DeleteExpr(i);
  vc_DeleteExpr(c7);
  vc_DeleteExpr(ilt7);
  vc_DeleteExpr(igt7);
  vc_DeleteExpr(falsee);
  vc_Destroy(vc);

}
